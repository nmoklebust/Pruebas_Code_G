# Figuras de validación en mezclas NaCl–KCl

El notebook `mixture_validation_figures.ipynb` produce las figuras originales y las cuatro clases de gráficos adicionales solicitadas. Todos los títulos, ejes, leyendas y anotaciones gráficas están en español. Cada figura combinada tiene además versiones individuales para facilitar su lectura.

**No se entrenan modelos ni se calculan predicciones nuevas.** Se utilizan exactamente las predicciones individuales obtenidas durante la validación externa anterior de los modelos finales proporcionados sobre las nuevas mezclas. Los datos de entrada permanecen intactos.

## Inicio rápido

1. Extraiga el paquete completo y conserve la carpeta `data/` junto al notebook.
2. Desde la carpeta extraída, cree un entorno e instale las dependencias:

   ```bash
   python -m venv .venv
   source .venv/bin/activate
   python -m pip install -r requirements.txt
   python -m jupyterlab
   ```

   En Windows, la activación es `.venv\Scripts\activate`.
3. Abra `mixture_validation_figures.ipynb` y ejecute todas las celdas en orden. Si el directorio de trabajo no es la carpeta del notebook, cambie `ROOT` en la primera celda de código.
4. Consulte `figures/` para las figuras combinadas y `figures/individuales/` para las individuales. Cada una se guarda en PNG a 220 dpi y en PDF vectorial.
5. Abra `tables/indice_figuras.csv` para localizar cada archivo por familia, modelo y mezcla.

El notebook entregado ya contiene los resultados de su ejecución. Por defecto, muestra las figuras combinadas y guarda las individuales sin mostrarlas dentro del notebook. Cambie `SHOW_INDIVIDUAL = True` para mostrarlas también. La generación de muchos PDF y PNG puede tardar aproximadamente unos minutos, según el equipo. No se necesita acceso a internet después de instalar las dependencias.

## Procedencia de los datos

Los tres CSV incluidos son copias, sin modificaciones, de las tablas generadas al ejecutar el notebook de validación que usted proporcionó, con sus modelos finales y su dataset de mezclas:

| Archivo incluido | Archivo generado en la validación previa | Objetivo nominal |
|---|---|---|
| `data/NaCl_predictions.csv` | `/workspace/ml_review/results/NaCl/predicciones.csv` | Concentración de NaCl |
| `data/KCl_predictions.csv` | `/workspace/ml_review/results/KCl/predicciones.csv` | Concentración de KCl |
| `data/PBS_predictions.csv` | `/workspace/ml_review/results/PBS/predicciones.csv` | Cloruro aportado por NaCl + KCl |

La ejecución anterior aplicó nueve modelos finales distintos, procedentes del archivo original `DATA_ML.zip`, a `mixed_nacl_kcl_ml_wide.csv`. Utilizó las funciones originales de inferencia y evaluación, el preprocesamiento guardado en cada modelo y scikit-learn 1.6.1. Los archivos de modelos duplicados no se contaron dos veces. Este notebook gráfico no requiere los `.joblib` ni el ZIP original: las tablas de predicciones incluidas son suficientes para reproducir las figuras.

Cada familia contiene tres modelos y 300 predicciones por modelo. Son **predicciones para las mezclas nuevas**, no predicciones sobre los datos de entrenamiento ni puntuaciones de validación cruzada.

### Correspondencia entre cada predicción y su objetivo

- Modelos entrenados con **NaCl**: `valor_real_mM` debe ser igual a `nominal_nacl_mM`.
- Modelos entrenados con **KCl**: `valor_real_mM` debe ser igual a `nominal_kcl_mM`.
- Modelos entrenados con **PBS**: `valor_real_mM` debe ser igual a `nominal_nacl_mM + nominal_kcl_mM`, el cloruro nominal aportado por ambas sales.

Cada sal aporta un cloruro por unidad fórmula; la suma se expresa en mM. No representa una concentración de PBS ni un ensayo químico independiente de cloruro.

| Columna original | Información que proporciona |
|---|---|
| `familia` | Solución utilizada para entrenar el modelo: NaCl, KCl o PBS |
| `modelo` | Identificador del modelo final |
| `row_index`, `sample_id` | Identidad de la misma observación entre modelos y familias |
| `nominal_nacl_mM`, `nominal_kcl_mM` | Composición nominal de la mezcla, en mM |
| `objetivo` | Nombre del objetivo que corresponde a la familia |
| `valor_real_mM` | Concentración nominal correcta para esa predicción |
| `valor_predicho_mM` | Predicción individual guardada, en mM |
| `error_mM` | Predicción menos valor nominal, en mM |
| `physical_sensor`, `electrode_pair`, `repetition`, `source_file` | Metadatos conservados de la observación; no implican independencia estadística |

Se mantienen los nombres originales de las columnas para facilitar la trazabilidad, aunque los textos de las figuras están en español. El lector valida valores finitos, objetivos y errores coherentes, ausencia de duplicados y cobertura idéntica de observaciones entre todos los modelos. No se rellenan valores ni se descartan observaciones silenciosamente. Las huellas SHA-256 de los CSV se guardan en `tables/run_manifest.json`.

### Clave de mezclas

Los identificadores M1–M5 se asignan ordenando las concentraciones nominales, no mediante los porcentajes de disolución madre ni las letras del dataset original.

| Mezcla | NaCl (mM) | KCl (mM) | Cloruro total (mM) | Observaciones por modelo | Marcador |
|---|---:|---:|---:|---:|---|
| M1 | 30.8 | 8 | 38.8 | 60 | Círculo |
| M2 | 61.6 | 4 | 65.6 | 60 | Cuadrado |
| M3 | 61.6 | 6 | 67.6 | 60 | Triángulo |
| M4 | 92.4 | 4 | 96.4 | 60 | Rombo |
| M5 | 123.2 | 2 | 125.2 | 60 | Cruz rellena |

El notebook genera esta clave a partir de los datos y la guarda en `tables/mixture_key.csv`.

## Configuración y colores

La primera celda de código contiene:

- `MODEL_SETS`: los tres modelos de comparación por familia. El orden se respeta en todas las figuras de esa familia.
- `SELECTED_MODEL`: el modelo mostrado en las figuras originales de predicción y respuesta con objetivo fijo. Valores iniciales: **PLS para NaCl, SVR para KCl y Ridge para PBS**. Esta selección descriptiva se basa en el menor MAE global observado anteriormente, no en una selección independiente anterior a la evaluación.
- `COLORS`: **NaCl azul** `#0072B2`, **KCl naranja** `#D55E00`, **PBS verde** `#009E73`. Se conserva la asignación de la primera versión; se usan intensidades del mismo color para distinguir modelos donde corresponde.
- `POINT_ALPHA`: transparencia de los puntos individuales, inicialmente 0.35.
- `RUN_RESPONSE_FIGURE`: activa la comparación original con objetivo fijo.
- `RUN_BOXPLOTS`: activa las cajas originales de errores.
- `RUN_NEW_PLOTS`: activa los cuatro tipos nuevos.
- `SHOW_INDIVIDUAL`: muestra o no las figuras individuales dentro del notebook; **siempre se guardan** cuando su grupo está activado.
- `SHOW_DUMBBELL_IQR`: añade el rango intercuartílico de predicciones individuales a las figuras de distancias.

Los modelos mantienen sus identificadores en los CSV. Las etiquetas gráficas son Regresión lineal, PLS, Ridge, SVR (RBF) y PCA + GPR.

## Figuras conservadas, traducidas y con versiones individuales

### 01. Predicción frente a concentración nominal

Una figura combinada con tres paneles y tres figuras individuales, una por familia. El eje horizontal es el objetivo nominal correcto; el vertical es la predicción. Se utilizan formas por mezcla y transparencia, sin desplazar las coordenadas. La línea discontinua es la identidad: puntos por encima indican sobrepredicción; por debajo, subpredicción. Los ejes tienen iguales límites y proporción dentro de cada panel; los rangos varían entre objetivos.

Combinada: `figures/01_predicted_vs_actual.*`.
Individuales: `figures/individuales/01_prediccion_<familia>.*`.

### 02. Mapas de calor del MAE

Filas: mezclas; columnas: tres modelos. Cada celda muestra:

`MAE = media(abs(predicción individual − valor nominal individual))`.

Se toma el valor absoluto **antes** de promediar. Los colores van desde blanco hasta el color de la familia. Cada familia tiene su propia escala desde cero; para comparar entre objetivos deben leerse los números y las barras, no solo la intensidad. Las mismas escalas se mantienen entre la figura combinada y su versión individual.

Combinada: `figures/02_mae_heatmaps.*`.
Individuales: `figures/individuales/02_mapa_MAE_<familia>.*`.

### 03. Respuesta a la otra sal con objetivo fijo

La detección de composiciones válidas es automática. En estos datos existen dos comparaciones:

- NaCl fijo en **61.6 mM**, con KCl en **4 y 6 mM**; se muestran predicciones del modelo NaCl seleccionado.
- KCl fijo en **4 mM**, con NaCl en **61.6 y 92.4 mM**; se muestran predicciones del modelo KCl seleccionado.

Se muestran todas las predicciones y rombos vacíos para sus medias. La línea horizontal es el valor nominal fijo. No se ajustan pendientes ni se trazan líneas entre medias. Si no existen comparaciones válidas, el notebook indica que se omite el gráfico.

Combinada: `figures/03_companion_response.*`.
Individuales: `figures/individuales/03_respuesta_<familia>_<número>.*`.

### 04. Cajas del error firmado por mezcla

Tres modelos lado a lado por mezcla, separados por familia. La línea cero permite identificar el sentido del error. La caja representa percentiles 25–75, la línea central es la mediana, los bigotes alcanzan las observaciones extremas dentro de 1.5 rangos intercuartílicos de la caja y los valores exteriores se muestran. No se eliminan observaciones de los cálculos.

Combinada: `figures/04_signed_error_boxplots.*`.
Individuales: `figures/individuales/04_cajas_error_<familia>.*`.

## Cuatro tipos de gráficos nuevos

### 05. Errores individuales y mediana por mezcla

- Eje horizontal: composición de la mezcla; las versiones individuales incluyen las concentraciones completas y las combinadas usan M1–M5 con la clave disponible.
- Eje vertical: `predicción − valor nominal`, en mM.
- Se muestran todas las observaciones como puntos pequeños transparentes, un rombo negro para la mediana de cada mezcla y una línea horizontal cero.
- Cada familia tiene una figura con tres paneles, uno por modelo, y tres figuras individuales. Los límites verticales son comunes para todos los modelos del mismo objetivo.

Para reducir la superposición, los puntos reciben un desplazamiento horizontal determinista entre −0.08 y +0.08 unidades **dentro de una categoría discreta**. Es exclusivamente visual, no modifica errores ni representa cambios de composición. Las otras figuras con ejes numéricos conservan las coordenadas exactas.

Combinadas: `figures/05_errores_individuales_<familia>.*`.
Individuales: `figures/individuales/05_error_<familia>_<modelo>.*`.

### 06. Cajas de predicciones y referencia nominal

Una figura por objetivo con un panel para cada mezcla, y una figura individual por cada combinación de objetivo y mezcla. El eje horizontal presenta los tres modelos en orden fijo; el vertical muestra concentraciones predichas. Cada caja usa las 60 observaciones correspondientes. Una línea discontinua etiquetada indica el valor nominal correcto de esa mezcla y objetivo.

Los límites verticales son comunes para las cinco mezclas del mismo objetivo e incluyen todas las predicciones y referencias, sin recortes. Los cuartiles, bigotes y puntos exteriores tienen el mismo significado que en las cajas de error.

Una caja estrecha indica poca variación; si está alejada de la referencia, esa consistencia puede coexistir con sesgo. No equivale a mayor exactitud.

Combinadas: `figures/06_cajas_predicciones_<familia>.*`.
Individuales: `figures/individuales/06_predicciones_<familia>_<mezcla>.*`.

### 07. Distancia entre valor nominal y predicción media

El eje vertical presenta las mezclas; el horizontal, concentración en mM. Cada segmento conecta un círculo vacío en el valor nominal y un rombo de color en la media de las predicciones. Hay paneles y archivos individuales por modelo y objetivo, con límites comunes dentro del objetivo.

Por defecto se añade una barra fina, ligeramente desplazada verticalmente, que representa los percentiles 25–75 de las predicciones individuales. **No es un intervalo de confianza ni incertidumbre de la media.** Se puede ocultar con `SHOW_DUMBBELL_IQR = False`.

La longitud del segmento es `abs(media(predicción) − valor nominal)`, que puede diferir del MAE. Los errores positivos y negativos pueden cancelarse en la media. Una conexión corta no garantiza poca dispersión.

Combinadas: `figures/07_distancias_<familia>.*`.
Individuales: `figures/individuales/07_distancia_<familia>_<modelo>.*`.

### 08. Error frente a la composición

El eje vertical es el error firmado y se incluye la línea cero. Se muestran las observaciones individuales y rombos vacíos para las medianas de cada grupo con igual objetivo y concentración del componente del eje horizontal. Las formas distinguen **concentraciones nominales del objetivo**, no modelos ni nuevas categorías inventadas. No se desplazan los puntos, no se unen y no se ajustan regresiones.

- NaCl: eje horizontal = concentración de KCl.
- KCl: eje horizontal = concentración de NaCl.
- PBS: se producen **dos vistas**, frente a NaCl y frente a KCl. El objetivo es cloruro total, NaCl + KCl, por lo que no hay una sola sal acompañante independiente. Los títulos identifican estos ejes como componentes de la mezcla.

Existen cuatro figuras combinadas con tres modelos por vista y doce figuras individuales. Los límites del error son comunes por objetivo. Las vistas PBS son asociaciones descriptivas; no permiten separar por sí solas la contribución de cada componente al error. Incluso con objetivo fijo, la cobertura del sensor puede confundir la comparación.

Combinadas: `figures/08_error_composicion_<familia>_vs_<componente>.*`.
Individuales: `figures/individuales/08_composicion_<familia>_<modelo>_vs_<componente>.*`.

## Resúmenes, índice y reproducción

Con las opciones iniciales y los datos actuales se generan **73 figuras: 17 combinadas y 56 individuales**, cada una en PNG y PDF. No hace falta revisar todas para redactar un informe breve: comience con predicción frente a valor nominal y errores individuales por mezcla; añada cajas de predicciones si la variabilidad es relevante.

| Archivo | Contenido |
|---|---|
| `tables/indice_figuras.csv` | Nombres, rutas, versión, familia, modelo y mezcla de las figuras generadas |
| `tables/mixture_key.csv` | Clave de composiciones y marcadores |
| `tables/mixture_model_errors.csv` | 45 grupos mezcla/modelo: recuento, MAE, sesgo, mediana del error, objetivo, media, mediana y cuartiles de predicciones |
| `tables/companion_response_means.csv` | Cuatro medias de las comparaciones originales con objetivo fijo |
| `tables/medianas_error_composicion.csv` | 60 medianas con recuentos para las cuatro vistas de composición y sus tres modelos |
| `tables/run_manifest.json` | Versiones de paquetes, opciones, selección de modelos, colores y huellas de los CSV |
| `tables/verification.json` | Registro de las comprobaciones realizadas durante esta entrega |

Los nombres de archivo anteriores 01–04 se conservan y su contenido gráfico se actualiza al español. Cada nueva ejecución sobrescribe sus salidas; no elimina automáticamente archivos de ejecuciones anteriores al desactivar opciones. Utilice el índice y las opciones de la ejecución actual para identificar sus resultados. Ningún archivo de entrada se modifica.

`requirements.txt` registra las versiones de las dependencias gráficas utilizadas; JupyterLab se incluye como interfaz opcional. El notebook fue ejecutado con Python 3.12. Los resúmenes de MAE, sesgo y recuentos se verificaron contra los resultados anteriores. También se comprobaron las nuevas medias, medianas y cuantiles y la integridad de los CSV de entrada. Las predicciones siguen siendo exactamente las mismas.

## Límites de interpretación

- Las concentraciones son nominales, no medidas por ensayos químicos independientes.
- Hay cinco composiciones con mediciones repetidas. Las 300 observaciones no representan 300 composiciones preparadas independientemente. No se calculan intervalos de confianza ni pruebas de significación.
- La cobertura de sensores es desigual. En la comparación con NaCl fijo se usan A/C/D para ambas mezclas; en la comparación con KCl fijo cambia de A/B/C/D a B/C/D. Un cambio de predicción no demuestra por sí solo un efecto causal de la otra sal.
- Cuando ambos componentes cambian, sus efectos no se pueden separar con una asociación gráfica. La forma del marcador ayuda a identificar el objetivo, pero no resuelve la confusión.
- Las predicciones PBS evalúan transferencia a una matriz distinta. La concordancia no demuestra especificidad de cloruro.
- El intervalo real de entrenamiento de KCl recuperado del modelo GPR es **2–10 mM**, con niveles 2, 4, 5, 6, 8 y 10 mM. Los valores 20–100 del campo de metadatos no deben interpretarse como concentraciones mM ni usarse para afirmar que todas las mezclas KCl son extrapolación.
- No se indicó un umbral de exactitud aceptable. Mostrar un modelo no certifica su idoneidad ni identifica la causa de sus errores.

## Autoría de esta actualización

Los modelos y el dataset originales fueron aportados por usted. Las predicciones se obtuvieron anteriormente con sus funciones originales de evaluación. El notebook de visualización, este README, las figuras adicionales y los resúmenes descriptivos son código y documentación añadidos para su solicitud. No se sustituyeron observaciones ni se modificó el modelado.
