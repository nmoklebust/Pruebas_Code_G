# Figures for external NaCl–KCl mixture validation

`mixture_validation_figures.ipynb` produces all four requested visualizations from the **previously calculated individual predictions**. The notebook is delivered with executed outputs. It neither loads `.joblib` models nor trains, recalibrates or changes predictions. The original dataset, models and validation notebook remain unchanged.

## Quick start

1. Extract this entire package, keeping `data/` beside the notebook.
2. In a terminal in that folder, create and activate a Python environment, then install the recorded dependencies:
   ```bash
   python -m venv .venv
   source .venv/bin/activate
   python -m pip install -r requirements.txt
   python -m jupyterlab
   ```
3. Open `mixture_validation_figures.ipynb` in that folder and select **Run All**. The notebook assumes its working directory contains `data/`; set `ROOT` in the first code cell if necessary. No network access is needed for plotting once dependencies are installed.
4. Review the displayed figures and the saved PNG/PDF files in `figures/`. The notebook writes CSV summaries and a run manifest in `tables/`.

The notebook does not install packages itself. Python 3.12 was used for the delivered execution. `requirements.txt` records the tested visualization packages and a JupyterLab requirement for opening the notebook; JupyterLab itself is not needed when another notebook frontend is available. `tables/run_manifest.json` records exact numerical/plotting versions used in this run.

## Information used and its provenance

The input files are copies of the `predicciones.csv` tables generated during the earlier external-validation run in this conversation:

| Packaged input | Original generated source | Target |
|---|---|---|
| `data/NaCl_predictions.csv` | `/workspace/ml_review/results/NaCl/predicciones.csv` | Nominal NaCl concentration |
| `data/KCl_predictions.csv` | `/workspace/ml_review/results/KCl/predicciones.csv` | Nominal KCl concentration |
| `data/PBS_predictions.csv` | `/workspace/ml_review/results/PBS/predicciones.csv` | Nominal chloride contributed by NaCl + KCl |

That earlier run applied nine unique exported models from the supplied `DATA_ML.zip` to `mixed_nacl_kcl_ml_wide.csv`. It used the supplied validation notebook's inference functions, matched scikit-learn 1.6.1, and preserved each export's existing preprocessing. The three configured comparison models per solution each have 300 individual predictions. Duplicate exported model files were not counted twice. This visualization notebook uses those stored predictions, **not training scores, cross-validation scores, aggregated predictions, or newly fitted models**. The original ZIP is not required to regenerate these figures; the packaged CSVs are sufficient.

The current inputs contain five nominal compositions, each with 60 spectra:

| Plot ID | NaCl (mM) | KCl (mM) | Chloride from both salts (mM) | Marker |
|---|---:|---:|---:|---|
| M1 | 30.8 | 8 | 38.8 | Circle |
| M2 | 61.6 | 4 | 65.6 | Square |
| M3 | 61.6 | 6 | 67.6 | Upward triangle |
| M4 | 92.4 | 4 | 96.4 | Diamond |
| M5 | 123.2 | 2 | 125.2 | Filled plus |

Mixture IDs are plotting labels assigned by sorting `(nominal_nacl_mM, nominal_kcl_mM)`; they are not the source dataset's original letter IDs. The notebook regenerates its key from the loaded inputs. It does not assume that stock-solution percentages are mM. The chloride target is `nominal_nacl_mM + nominal_kcl_mM`, in mM, since each salt contributes one chloride per formula unit. It is not a PBS dilution or an independently assayed chloride value.

### Source column meanings

| Column | Meaning/use |
|---|---|
| `familia` | Training-solution family: NaCl, KCl or PBS |
| `modelo` | Saved estimator identifier used to filter/group observations |
| `row_index`, `sample_id` | Identify the same spectrum across all models/families |
| `nominal_nacl_mM`, `nominal_kcl_mM` | Nominal mixture concentrations; define composition and fixed-component comparisons |
| `objetivo` | Target column name; checked against the family's expected target |
| `valor_real_mM` | Actual nominal target for this family; horizontal coordinate in figure 1 |
| `valor_predicho_mM` | Saved prediction in mM; vertical coordinate in figures 1 and 3 |
| `error_mM` | Signed error, prediction minus nominal; plotted in figure 4 |
| `physical_sensor`, `electrode_pair`, `repetition`, `source_file` | Retained descriptive metadata; not treated as independent-replicate declarations |

The loader requires nonempty tables with finite numerical values, no missing required values, one row per model/observation, consistent targets and signed errors, and identical observation identities and compositions across the selected models and families. It checks PBS's actual target against the salt sum. Missing combinations or invalid data raise errors; observations are not silently dropped or imputed. Input checksums are recorded in the manifest.

## Configuration

The first code cell contains the paths, model sets, displayed models, colors and optional-figure switches.

- `MODEL_SETS`: exactly three distinct comparison models per family. The defaults use all three available models for each solution.
- `SELECTED_MODEL`: the one model per family displayed in figures 1 and 3. Defaults are **NaCl PLS**, **KCl SVR (RBF)** and **PBS Ridge**, chosen for lowest overall observed MAE within each family in the earlier external run. This is a descriptive choice made after evaluation, not independently validated model selection. Changing it does not recalculate predictions.
- `COLORS`: NaCl blue `#0072B2`, KCl orange `#D55E00`, PBS green `#009E73`. No earlier fixed family palette was supplied; these defaults can be replaced with your assigned colors. Every figure uses this mapping consistently.
- `RUN_RESPONSE_FIGURE` and `RUN_BOXPLOTS`: enable/disable the optional figures.
- `POINT_ALPHA`: transparency for individual observations, initially 0.35.

The short labels Linear, PLS, Ridge, SVR (RBF), and PCA + GPR are presentation names for the original estimator identifiers. Filtering does not change their values.

## How each figure is computed and plotted

### 1. Predicted versus actual concentration

`figures/01_predicted_vs_actual.{png,pdf}` has three panels for NaCl-, KCl-, and PBS-trained models. Each panel shows all 300 observations for its selected model. The x axis is that family's nominal target, the y axis is its saved prediction. Shapes identify mixtures and the shared legend gives the full composition in mM. Transparency reveals overlapping observations; there is **no jitter** or movement of concentration coordinates.

A black dashed identity line shows predicted = actual. Points above it overpredict, below it underpredict; a weak vertical response across actual concentrations suggests poor concentration tracking. Each panel has equal x/y limits and equal aspect ratio, but different targets have independent ranges so low-concentration KCl remains readable. Neither negative predictions nor extreme predictions are clipped.

### 2. MAE heatmaps by mixture and model

`figures/02_mae_heatmaps.{png,pdf}` has three panels, one per family. Rows are the five compositions; columns are the family's three configured models. For each cell:

`MAE = mean(abs(individual prediction − individual nominal target))`.

Absolute errors are computed **before** averaging. This is not `abs(mean(prediction) − target)`, which could hide canceling errors. Each heatmap uses white-to-family-color intensity and a linear scale from zero to that family's largest cell MAE. Each panel has its own labeled mM colorbar. Darker means larger error **within that panel**; compare the numerical values/colorbars across families, not darkness alone. Missing values are rejected instead of rendered as zero.

The numerical cell values, counts, signed biases and descriptive mean predictions are exported to `tables/mixture_model_errors.csv`.

### 3. Response to the accompanying component (optional)

`figures/03_companion_response.{png,pdf}` is produced only if fixed-target comparisons exist. The code detects fixed concentrations with at least two distinct concentrations of the other salt. The current dataset supports two panels:

- Fixed NaCl = **61.6 mM**: KCl changes from **4 to 6 mM**; y shows selected NaCl-model predictions, and the reference line is 61.6 mM.
- Fixed KCl = **4 mM**: NaCl changes from **61.6 to 92.4 mM**; y shows selected KCl-model predictions, and the reference line is 4 mM.

Points remain individual observations with the same mixture shapes and transparency. Large outlined diamonds show the arithmetic mean prediction at each accompanying-component concentration. There are no fitted slopes, connecting trend lines, confidence intervals or hypothesis tests. `tables/companion_response_means.csv` contains these means and counts. If no valid fixed-target comparisons exist, the notebook explicitly reports that it skipped the figure rather than plotting a confounded comparison.

Holding the nominal target fixed is useful descriptively but does not isolate chemical interference from sensor or acquisition differences. The fixed-NaCl comparison uses sensors A/C/D in both mixtures, while the fixed-KCl comparison changes sensor coverage (A/B/C/D versus B/C/D). Neither panel establishes a causal component effect.

### 4. Signed-error boxplots by mixture (optional alternative)

`figures/04_signed_error_boxplots.{png,pdf}` has three family panels. Each mixture contains three side-by-side boxes, one per configured model, using shades of its family's color. All individual signed errors contribute: `error = prediction − nominal`.

Boxes show the 25th to 75th percentiles, black lines show medians, whiskers extend to the most extreme data points within 1.5 interquartile ranges of the box, and observations outside those whiskers are shown. Those observations are displayed, not removed from calculations. A black dashed zero line separates overprediction from underprediction. Panels use independent y scales. The mixture key maps M1–M5 back to physical compositions.

The heatmap emphasizes average absolute error; these boxplots emphasize spread and bias. Both are included by default so you can choose which better supports your presentation.

## Interpretation limits

- Nominal labels are used, not independent chemical assays.
- Repeated spectra/electrode measurements are descriptive observations, not automatically independent experimental replicates. Counts do not justify independent-sample confidence intervals or significance claims.
- There are five compositions and unbalanced sensor coverage. Few compositions and partial NaCl/KCl co-variation limit conclusions about ion specificity and generalization.
- PBS-to-mixture predictions test transfer across matrices. Agreement does not prove chloride specificity.
- The actual KCl training targets recovered from the saved GPR model are **2, 4, 5, 6, 8, 10 mM**. The metadata field `[20,40,50,60,80,100]` was previously misinterpreted as mM; it must not be used to label the 2–8 mM external KCl observations as concentration extrapolation.
- No accuracy acceptance threshold was supplied. Plotting a model does not certify acceptable performance or establish the cause of its errors.

## Generated files and verification

Every figure is saved as a 220 dpi PNG and vector PDF. Generated files are overwritten on rerun; inputs are not modified. Optional files already on disk from an earlier run are not deleted when a switch is disabled: use displayed cell messages and the switches to determine what was generated in the current run.

`tables/mixture_key.csv` provides composition labels and markers; `tables/mixture_model_errors.csv` provides 45 mixture/model summaries; `tables/companion_response_means.csv` provides the four mean-response values for the current two comparisons; `tables/run_manifest.json` records versions, configuration and input SHA-256 checksums.

The delivered notebook was executed end to end against the packaged CSVs. All plots were generated; grouped MAEs were checked against the earlier validation summaries. The figures do not alter the prior model predictions or metrics.
