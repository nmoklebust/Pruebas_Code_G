# Comparaciones ML: leyendas y concentración nominal

Estas cinco figuras corresponden a la evaluación de los modelos en los resultados originales exportados. Son distintas de las figuras de nuevas mezclas de `../salidas/figuras/`.

## Entrada y ejecución

- `ML_Results.zip` es una copia intacta del archivo recibido `ML_Results-20261030T223432Z-1-001.zip`.
- `EIS_Resultados_ML_Tesis_final_actualizado.ipynb` adapta el notebook original `EIS_Resultados_ML_Tesis_final.ipynb` de `Material_Figuras.zip`. Lee `metadata.json`, `metrics.csv`, `predictions.csv`, parámetros y resultados de búsquedas desde el ZIP; no reentrena modelos ni repite búsquedas.
- Para reproducir, use el entorno de `../requirements.txt`, abra el notebook desde esta carpeta y ejecute todas las celdas. `ROOT = Path.cwd()` debe apuntar aquí. El ZIP se lee directamente; no es necesario montar Drive. Si cambia la ubicación, ajuste `ROOT` o `RUTAS_ENTRADA`.

Las funciones de importación, normalización de unidades, pareo de observaciones, cálculo de métricas y selección automática de finalistas se conservan. Los datos proceden de los resultados reales aportados. Los top 3 esperados solo se utilizan como verificación posterior, igual que en el notebook original. No se sustituyen ausencias con valores inventados. La cobertura, selección y métricas completas quedan en `salidas/tablas/`.

## Figuras y cambios solicitados

| Archivo base | Diseño y cambio |
|---|---|
| `EIS_ML_F1_estrategias_MAE` | Tres paneles verticales; puntos de 80/20, GroupKFold y LOCO. Leyenda ampliada en la versión principal, con más separación entre entradas y margen inferior. |
| `EIS_ML_F2_efecto_optimizacion_LOCO` | Tres paneles horizontales de MAE; configuraciones base/optimizada unidas. Leyenda más legible y espacio inferior ampliado. RMSE permanece en las tablas. |
| `EIS_ML_F3_interpolacion_NaCl_finalistas` | Cuatro paneles azules. Títulos «Nominal: … mM» y leyenda «Concentración nominal excluida». |
| `EIS_ML_F4_interpolacion_KCl_finalistas` | Cuatro paneles naranjas; los mismos cambios de texto y tamaño de leyenda. |
| `EIS_ML_F5_interpolacion_PBS_finalistas` | Tres paneles verdes; los mismos cambios de texto y tamaño de leyenda. |

Se mantienen modelos, orden, concentraciones, cajas, medianas, puntos, conexiones y referencias nominales del código original. Las mediciones repetidas siguen siendo observaciones descriptivas, no réplicas independientes por defecto. Los saltos de línea en títulos conservan el texto y permiten aumentar la tipografía.

## Tamaño final y leyendas

Se aplica el criterio de visibilidad de la última tanda EIS:

- `salidas/figuras_principales/`: ancho de **34 cm**, título **40 pt**, ejes **18 pt**, números **12 pt** y leyendas **19,125 pt**. Al insertar esta versión a 16 cm de ancho, la leyenda equivale a `19,125 × 16/34 = 9 pt`.
- `salidas/Word/figuras_principales/`: exportación directa a **16 cm** de ancho, título **18 pt**, ejes **9 pt**, números **8 pt** y leyendas físicas de **9 pt**. Inserte a 16 cm sin deformar la proporción.

Las alturas dependen del número y disposición de paneles, y se registran en los manifiestos. El espacio inferior adicional se incorpora a la altura base. La exportación no recorta automáticamente el lienzo; no se usa `bbox_inches='tight'`. Las copias Word se vuelven a dibujar con los mismos datos, no se amplía o reduce un PNG ya creado. Se entregan PNG a 600 dpi, PDF y SVG vectoriales. No se añaden pies de figura.

Las dos escalas usan las mismas observaciones y selecciones en memoria. El perfil Word guarda su manifiesto y configuración separados para conservar la trazabilidad de las versiones principales. Cambiar el ancho de inserción en Word cambia también los puntos efectivos: los 9 pt se garantizan a 16 cm.

## Verificación

`salidas/verificacion_presentacion.json` registra la comparación con una ejecución del notebook original con las mismas entradas: métricas, predicciones y ranking sin cambios; paneles y etiquetas verificados; leyendas de 9 pt en Word y comprobación de su separación de los ejes. Los archivos CSV conservan precisión completa. Los cambios se limitan a presentación, rutas portables y exportaciones adicionales.
