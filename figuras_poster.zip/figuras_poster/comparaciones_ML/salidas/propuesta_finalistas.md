# Selección de finalistas por solución

**NaCl.** Los tres modelos con menor MAE LOCO; selección automática de una configuración completa por modelo; cobertura completa del plan. Exclusiones (%): [40.0, 60.0, 80.0, 90.0]; unión de exclusiones LOCO exportadas; no se infieren exclusiones a partir de niveles de entrenamiento.

**Configuración elegida por modelo:**

- **PLS · Combined · Optimizado**: MAE=4.52108 mM; menor MAE entre 2 configuraciones elegibles.

- **OLS · Combined · Base**: MAE=4.5624 mM; empate exacto de las tres métricas; regla determinista documentada.

Empate completo entre Combined/Base, Combined/Optimizado. Desempate: Base primero, después características alfabéticas e identificador estable.

- **Ridge · Combined · Optimizado**: MAE=4.57195 mM; menor MAE entre 2 configuraciones elegibles.

- **GPR-PCA · Combined · Optimizado**: MAE=5.01626 mM; menor MAE entre 3 configuraciones elegibles.

- **SVR · Combined · Optimizado**: MAE=5.79911 mM; menor MAE entre 3 configuraciones elegibles.

- **XGB · Cartesian · Base**: MAE=24.5927 mM; única configuración elegible.

- **RF · Cartesian · Base**: MAE=26.5086 mM; única configuración elegible.

**Los tres modelos con menor MAE LOCO (orden fijo en todos los paneles):**

- **PLS · Combined · Optimizado**: Puesto 1 por MAE global; MAE=4.52108, RMSE=6.06434, peor RMSE=7.53705 mM.

- **OLS · Combined · Base**: Puesto 2 por MAE global; MAE=4.5624, RMSE=6.28053, peor RMSE=7.8935 mM.

- **Ridge · Combined · Optimizado**: Puesto 3 por MAE global; MAE=4.57195, RMSE=6.38313, peor RMSE=7.892 mM.

**Modelo seleccionado global:** PLS · Combined · Optimizado, primero en el ranking por MAE global LOCO.

**Mejor desempeño observado según MAE:** PLS (MAE=4.52108 mM).

El grupo mostrado se determina solo por MAE global. Los mínimos de RMSE global y peor RMSE son información complementaria y no sustituyen modelos del grupo.

Agregación sobre 725 observaciones comunes por configuración. Los CSV conservan la precisión completa; el resumen redondea solo para lectura.

La selección es descriptiva y no demuestra superioridad ni equivalencia estadística. La figura base/optimizado permanece independiente de esta selección.

**Verificación de referencia:** La selección calculada coincide con los tres modelos, características y modos de referencia, en el mismo orden.

**KCl.** Los tres modelos con menor MAE LOCO; selección automática de una configuración completa por modelo; cobertura completa del plan. Exclusiones (%): [40.0, 50.0, 60.0, 80.0]; unión de exclusiones LOCO exportadas; no se infieren exclusiones a partir de niveles de entrenamiento.

**Configuración elegida por modelo:**

- **GPR-PCA · Combined · Base**: MAE=0.193271 mM; menor MAE entre 2 configuraciones elegibles.

- **SVR · Combined · Base**: MAE=0.261021 mM; menor MAE entre 3 configuraciones elegibles.

- **PLS · Combined · Base**: MAE=0.364491 mM; menor MAE entre 2 configuraciones elegibles.

- **Ridge · Combined · Optimizado**: MAE=0.441835 mM; menor MAE entre 2 configuraciones elegibles.

- **OLS · Combined · Base**: MAE=0.461421 mM; empate exacto de las tres métricas; regla determinista documentada.

Empate completo entre Combined/Base, Combined/Optimizado. Desempate: Base primero, después características alfabéticas e identificador estable.

- **XGB · Cartesian · Base**: MAE=0.801029 mM; única configuración elegible.

- **RF · Cartesian · Base**: MAE=1.15106 mM; única configuración elegible.

**Los tres modelos con menor MAE LOCO (orden fijo en todos los paneles):**

- **GPR-PCA · Combined · Base**: Puesto 1 por MAE global; MAE=0.193271, RMSE=0.239281, peor RMSE=0.305314 mM.

- **SVR · Combined · Base**: Puesto 2 por MAE global; MAE=0.261021, RMSE=0.330285, peor RMSE=0.43942 mM.

- **PLS · Combined · Base**: Puesto 3 por MAE global; MAE=0.364491, RMSE=0.444917, peor RMSE=0.500559 mM.

**Modelo seleccionado global:** GPR-PCA · Combined · Base, primero en el ranking por MAE global LOCO.

**Mejor desempeño observado según MAE:** GPR-PCA (MAE=0.193271 mM).

El grupo mostrado se determina solo por MAE global. Los mínimos de RMSE global y peor RMSE son información complementaria y no sustituyen modelos del grupo.

Agregación sobre 720 observaciones comunes por configuración. Los CSV conservan la precisión completa; el resumen redondea solo para lectura.

La selección es descriptiva y no demuestra superioridad ni equivalencia estadística. La figura base/optimizado permanece independiente de esta selección.

**Verificación de referencia:** La selección calculada coincide con los tres modelos, características y modos de referencia, en el mismo orden.

**PBS.** Los tres modelos con menor MAE LOCO; selección automática de una configuración completa por modelo; cobertura completa del plan. Exclusiones (%): [40.0, 60.0, 80.0]; unión de exclusiones LOCO exportadas; no se infieren exclusiones a partir de niveles de entrenamiento.

**Configuración elegida por modelo:**

- **Ridge · Combined · Base**: MAE=4.21979 mM; menor MAE entre 2 configuraciones elegibles.

- **PLS · Combined · Base**: MAE=4.52886 mM; menor MAE entre 2 configuraciones elegibles.

- **SVR · Combined · Optimizado**: MAE=4.75873 mM; menor MAE entre 3 configuraciones elegibles.

- **OLS · Combined · Base**: MAE=5.19893 mM; empate exacto de las tres métricas; regla determinista documentada.

Empate completo entre Combined/Base, Combined/Optimizado. Desempate: Base primero, después características alfabéticas e identificador estable.

- **GPR-PCA · Polar · Optimizado**: MAE=15.47 mM; menor MAE entre 3 configuraciones elegibles.

- **XGB · Cartesian · Base**: MAE=23.104 mM; única configuración elegible.

- **RF · Cartesian · Base**: MAE=27.8017 mM; única configuración elegible.

**Los tres modelos con menor MAE LOCO (orden fijo en todos los paneles):**

- **Ridge · Combined · Base**: Puesto 1 por MAE global; MAE=4.21979, RMSE=5.24959, peor RMSE=5.45204 mM.

- **PLS · Combined · Base**: Puesto 2 por MAE global; MAE=4.52886, RMSE=5.86434, peor RMSE=7.48229 mM.

- **SVR · Combined · Optimizado**: Puesto 3 por MAE global; MAE=4.75873, RMSE=6.20611, peor RMSE=8.15352 mM.

**Modelo seleccionado global:** Ridge · Combined · Base, primero en el ranking por MAE global LOCO.

**Mejor desempeño observado según MAE:** Ridge (MAE=4.21979 mM).

El grupo mostrado se determina solo por MAE global. Los mínimos de RMSE global y peor RMSE son información complementaria y no sustituyen modelos del grupo.

Agregación sobre 543 observaciones comunes por configuración. Los CSV conservan la precisión completa; el resumen redondea solo para lectura.

La selección es descriptiva y no demuestra superioridad ni equivalencia estadística. La figura base/optimizado permanece independiente de esta selección.

**Verificación de referencia:** La selección calculada coincide con los tres modelos, características y modos de referencia, en el mismo orden.