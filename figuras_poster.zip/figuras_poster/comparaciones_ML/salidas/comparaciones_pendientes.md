# Cobertura y comparaciones pendientes

## Etapa 1

Disponibles: 63 / 63 combinaciones previstas.


## Etapa 2

Disponibles: 119 / 161 combinaciones previstas.


```text
solution   model feature_set strategy configuration  excluded_pct   estado
    NaCl     OLS    Combined     LOCO          Base          20.0 faltante
    NaCl     OLS    Combined     LOCO          Base         100.0 faltante
    NaCl   Ridge    Combined     LOCO          Base          20.0 faltante
    NaCl   Ridge    Combined     LOCO          Base         100.0 faltante
    NaCl     PLS    Combined     LOCO          Base          20.0 faltante
    NaCl     PLS    Combined     LOCO          Base         100.0 faltante
    NaCl      RF   Cartesian     LOCO          Base          20.0 faltante
    NaCl      RF   Cartesian     LOCO          Base         100.0 faltante
    NaCl     XGB   Cartesian     LOCO          Base          20.0 faltante
    NaCl     XGB   Cartesian     LOCO          Base         100.0 faltante
    NaCl     SVR    Combined     LOCO          Base          20.0 faltante
    NaCl     SVR    Combined     LOCO          Base         100.0 faltante
    NaCl GPR-PCA    Combined     LOCO          Base          20.0 faltante
    NaCl GPR-PCA    Combined     LOCO          Base         100.0 faltante
     KCl     OLS    Combined     LOCO          Base          20.0 faltante
     KCl     OLS    Combined     LOCO          Base         100.0 faltante
     KCl   Ridge    Combined     LOCO          Base          20.0 faltante
     KCl   Ridge    Combined     LOCO          Base         100.0 faltante
     KCl     PLS    Combined     LOCO          Base          20.0 faltante
     KCl     PLS    Combined     LOCO          Base         100.0 faltante
     KCl      RF   Cartesian     LOCO          Base          20.0 faltante
     KCl      RF   Cartesian     LOCO          Base         100.0 faltante
     KCl     XGB   Cartesian     LOCO          Base          20.0 faltante
     KCl     XGB   Cartesian     LOCO          Base         100.0 faltante
     KCl     SVR    Combined     LOCO          Base          20.0 faltante
     KCl     SVR    Combined     LOCO          Base         100.0 faltante
     KCl GPR-PCA    Combined     LOCO          Base          20.0 faltante
     KCl GPR-PCA    Combined     LOCO          Base         100.0 faltante
     PBS     OLS    Combined     LOCO          Base          20.0 faltante
     PBS     OLS    Combined     LOCO          Base         100.0 faltante
     PBS   Ridge    Combined     LOCO          Base          20.0 faltante
     PBS   Ridge    Combined     LOCO          Base         100.0 faltante
     PBS     PLS    Combined     LOCO          Base          20.0 faltante
     PBS     PLS    Combined     LOCO          Base         100.0 faltante
     PBS      RF   Cartesian     LOCO          Base          20.0 faltante
     PBS      RF   Cartesian     LOCO          Base         100.0 faltante
     PBS     XGB   Cartesian     LOCO          Base          20.0 faltante
     PBS     XGB   Cartesian     LOCO          Base         100.0 faltante
     PBS     SVR    Combined     LOCO          Base          20.0 faltante
     PBS     SVR    Combined     LOCO          Base         100.0 faltante
     PBS GPR-PCA       Polar     LOCO          Base          20.0 faltante
     PBS GPR-PCA       Polar     LOCO          Base         100.0 faltante
```

## Etapa 3

Disponibles: 132 / 204 combinaciones previstas.


```text
solution   model feature_set  excluded_pct configuration   estado
    NaCl     OLS    Combined          20.0          Base faltante
    NaCl     OLS    Combined          20.0    Optimizado faltante
    NaCl     OLS    Combined         100.0          Base faltante
    NaCl     OLS    Combined         100.0    Optimizado faltante
    NaCl   Ridge    Combined          20.0          Base faltante
    NaCl   Ridge    Combined          20.0    Optimizado faltante
    NaCl   Ridge    Combined         100.0          Base faltante
    NaCl   Ridge    Combined         100.0    Optimizado faltante
    NaCl     PLS    Combined          20.0          Base faltante
    NaCl     PLS    Combined          20.0    Optimizado faltante
    NaCl     PLS    Combined         100.0          Base faltante
    NaCl     PLS    Combined         100.0    Optimizado faltante
    NaCl      RF   Cartesian          20.0          Base faltante
    NaCl      RF   Cartesian         100.0          Base faltante
    NaCl     XGB   Cartesian          20.0          Base faltante
    NaCl     XGB   Cartesian         100.0          Base faltante
    NaCl     SVR    Combined          20.0          Base faltante
    NaCl     SVR    Combined          20.0    Optimizado faltante
    NaCl     SVR    Combined         100.0          Base faltante
    NaCl     SVR    Combined         100.0    Optimizado faltante
    NaCl GPR-PCA    Combined          20.0          Base faltante
    NaCl GPR-PCA    Combined          20.0    Optimizado faltante
    NaCl GPR-PCA    Combined         100.0          Base faltante
    NaCl GPR-PCA    Combined         100.0    Optimizado faltante
     KCl     OLS    Combined          20.0          Base faltante
     KCl     OLS    Combined          20.0    Optimizado faltante
     KCl     OLS    Combined         100.0          Base faltante
     KCl     OLS    Combined         100.0    Optimizado faltante
     KCl   Ridge    Combined          20.0          Base faltante
     KCl   Ridge    Combined          20.0    Optimizado faltante
     KCl   Ridge    Combined         100.0          Base faltante
     KCl   Ridge    Combined         100.0    Optimizado faltante
     KCl     PLS    Combined          20.0          Base faltante
     KCl     PLS    Combined          20.0    Optimizado faltante
     KCl     PLS    Combined         100.0          Base faltante
     KCl     PLS    Combined         100.0    Optimizado faltante
     KCl      RF   Cartesian          20.0          Base faltante
     KCl      RF   Cartesian         100.0          Base faltante
     KCl     XGB   Cartesian          20.0          Base faltante
     KCl     XGB   Cartesian         100.0          Base faltante
     KCl     SVR    Combined          20.0          Base faltante
     KCl     SVR    Combined          20.0    Optimizado faltante
     KCl     SVR    Combined         100.0          Base faltante
     KCl     SVR    Combined         100.0    Optimizado faltante
     KCl GPR-PCA    Combined          20.0          Base faltante
     KCl GPR-PCA    Combined          20.0    Optimizado faltante
     KCl GPR-PCA    Combined         100.0          Base faltante
     KCl GPR-PCA    Combined         100.0    Optimizado faltante
     PBS     OLS    Combined          20.0          Base faltante
     PBS     OLS    Combined          20.0    Optimizado faltante
     PBS     OLS    Combined         100.0          Base faltante
     PBS     OLS    Combined         100.0    Optimizado faltante
     PBS   Ridge    Combined          20.0          Base faltante
     PBS   Ridge    Combined          20.0    Optimizado faltante
     PBS   Ridge    Combined         100.0          Base faltante
     PBS   Ridge    Combined         100.0    Optimizado faltante
     PBS     PLS    Combined          20.0          Base faltante
     PBS     PLS    Combined          20.0    Optimizado faltante
     PBS     PLS    Combined         100.0          Base faltante
     PBS     PLS    Combined         100.0    Optimizado faltante
     PBS      RF   Cartesian          20.0          Base faltante
     PBS      RF   Cartesian         100.0          Base faltante
     PBS     XGB   Cartesian          20.0          Base faltante
     PBS     XGB   Cartesian         100.0          Base faltante
     PBS     SVR    Combined          20.0          Base faltante
     PBS     SVR    Combined          20.0    Optimizado faltante
     PBS     SVR    Combined         100.0          Base faltante
     PBS     SVR    Combined         100.0    Optimizado faltante
     PBS GPR-PCA       Polar          20.0          Base faltante
     PBS GPR-PCA       Polar          20.0    Optimizado faltante
     PBS GPR-PCA       Polar         100.0          Base faltante
     PBS GPR-PCA       Polar         100.0    Optimizado faltante
```

## Etapa 4

Modelos seleccionados: 9

## Estado de las cinco figuras principales

```text
      id_figura   estado                                                                                                                         detalle
 F1_estrategias generada                                                                              Ver reporte_F1_metricas_completas.csv y cobertura.
F2_optimizacion generada                                                                                              Solo MAE; RMSE completo en tablas.
        F3_NaCl generada Los tres modelos con menor MAE LOCO; selección automática de una configuración completa por modelo; cobertura completa del plan
         F4_KCl generada Los tres modelos con menor MAE LOCO; selección automática de una configuración completa por modelo; cobertura completa del plan
         F5_PBS generada Los tres modelos con menor MAE LOCO; selección automática de una configuración completa por modelo; cobertura completa del plan
```

Consulte reporte_cobertura_comparaciones.csv, reporte_cobertura_configuraciones_LOCO.csv y reporte_cobertura_observaciones_configuraciones.csv para los faltantes exactos.