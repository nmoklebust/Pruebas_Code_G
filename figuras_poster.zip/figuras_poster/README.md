# Figuras para el póster de resultados

Esta entrega adapta el formato de las figuras solicitadas a un póster de **62 cm de ancho × 91 cm de alto**, manteniendo los tamaños tipográficos del documento y, según la aclaración recibida, utilizando 25–30 cm de ancho en las figuras densas.

## Figuras generadas

| Figura solicitada | Estado | Archivo |
|---|---|---|
| 1. Voltametrías tras acondicionamiento | Generada desde los CSV originales | `salidas/figuras/01_CV_acondicionamiento.png` |
| 2. Panorama EIS | Generada desde los CSV originales | `salidas/figuras/02_panorama_EIS.png` |
| 3. Cajas LOCO | Generada con las exclusiones reales recibidas | `salidas/figuras/03_cajas_LOCO.png` |
| 4. Nominal frente a predicha en mezclas | Generada con los modelos finales y las mezclas recibidas | `salidas/figuras/04_predicciones_mezclas.png` |
| 5. Mapas de MAE | Generada desde las mismas predicciones de mezclas | `salidas/figuras/05_mapas_MAE.png` |

Las cinco figuras tienen PDF vectorial y su pie explicativo en un archivo de texto separado. La figura LOCO utiliza predicciones individuales obtenidas al excluir concentraciones, sin sustituirlas por inferencias de los modelos finales ajustados con todos los datos.

El archivo adicional `ML_Results-20261030T223432Z-1-001.zip` aportó las fuentes que faltaban. Para mantener la entrega compacta, `datos_LOCO/` conserva únicamente los 26 experimentos que contienen los nueve finalistas indicados, con sus 104 archivos originales `metadata.json`, `predictions.csv`, `metrics.csv` y `parameters.csv`. No se modificó su contenido. `datos_LOCO/origen_LOCO.json` registra el nombre y SHA-256 del ZIP completo y las huellas de cada archivo conservado. No es necesario el ZIP adicional completo para reproducir estas figuras: las fuentes pertinentes ya están incluidas.

## Contenido de la entrega

- `figuras_poster.ipynb`: notebook ejecutado, con configuración y resultados.
- `figuras_poster.py`: funciones de lectura, validación, inferencia y adaptación de formato; lo usa el notebook.
- `datos_LOCO/`: fuentes originales LOCO de los experimentos pertinentes, con trazabilidad al ZIP adicional.
- `reporte_predicciones_finalistas.csv`: tabla normalizada regenerada por el notebook desde esas fuentes.
- `procedencia_LOCO.csv`: relación entre modelo, configuración, exclusión, archivo y huella de origen.
- `Material_Figuras.zip`: copia intacta de su material de entrada. Permite reproducir la entrega sin depender del directorio temporal de esta conversación.
- `requirements.txt`: dependencias utilizadas, incluyendo scikit-learn 1.6.1, que coincide con las exportaciones.
- `salidas/figuras/`: PNG a 600 dpi y PDF al mismo tamaño físico.
- `salidas/pies/`: pies incluidos en las imágenes, también como texto reutilizable en el póster.
- `salidas/tablas/`: conteos, medias EIS, predicciones individuales, MAE, dimensiones, estado y manifiesto.
- `requisitos_recibidos.txt`: copia de las instrucciones de formato aportadas.

## Ejecución y rutas

Extraiga todo el paquete y conserve juntos el notebook, el archivo `.py` y `Material_Figuras.zip`. Desde esa carpeta:

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python -m jupyterlab
```

En Windows, active el entorno con `.venv\Scripts\activate`.

Abra `figuras_poster.ipynb` y ejecute todas las celdas. `ROOT = Path.cwd()` debe apuntar a su carpeta. Puede modificarlo para usar otra ubicación o una carpeta de Drive ya montada. El código no monta automáticamente Google Drive ni necesita credenciales adicionales.

La primera ejecución extrae el ZIP en `entradas/Material_Figuras/`. En las siguientes se verifica que los archivos sigan coincidiendo byte a byte con el ZIP; no se sobrescriben entradas alteradas. Los cambios de rutas, dimensiones y fuentes se hacen en la primera celda del notebook. Los resultados se guardan por separado en `salidas/`.

Se usó Python 3.12. El notebook no reentrena ni optimiza modelos. No se instala XGBoost porque ninguno de los nueve modelos finales recibidos lo necesita. Los paquetes numéricos están registrados en el manifiesto; cambios de versiones pueden introducir diferencias numéricas pequeñas.

## Tamaño físico, tipografía y resolución

| Figura | Ancho × alto finales | Resolución solicitada |
|---|---|---|
| CV | 25 × 25 cm | 600 dpi |
| EIS | 30 × 32 cm | 600 dpi |
| LOCO | 30 × 26 cm | 600 dpi |
| Mezclas | 30 × 22 cm | 600 dpi |
| MAE | 30 × 26 cm | 600 dpi |

Se conserva un título principal de **40 pt**, rótulos de ejes de **18 pt**, números de ejes de **12 pt**, leyendas y anotaciones de **18 pt**, letras de panel en negrita de **18 pt** y pies de **18 pt**. Los encabezados de columnas EIS son rótulos internos de 18 pt, sin repetir títulos largos en cada panel. Los colores de solución son NaCl azul, PBS verde y KCl naranja; CV utiliza colores fijos por electrodo.

Las figuras se exportan **sin `bbox_inches='tight'`** para no alterar su tamaño físico. La relación es `píxeles = cm / 2.54 × 600`, con el redondeo de la exportación. `dimensiones_exportaciones.csv` informa dimensiones y píxeles efectivamente guardados, además de los dpi leídos del PNG. Una diferencia inferior a un píxel por redondeo no altera la escala de impresión de forma significativa.

No reduzca posteriormente las imágenes si necesita conservar la tipografía indicada: reducir el tamaño impreso también reduce los puntos tipográficos. Cambie `dimensiones_cm` en el notebook y vuelva a exportar. La elección de dimensiones de cada figura no es una maquetación completa del póster: todavía debe reservarse espacio para título, texto, márgenes y otros contenidos.

## Qué significa `n`

`n` es el número de **barridos completos distintos** que aportan a cada línea o distribución. En EIS se cuenta `sample_id`, no las 41 filas de frecuencia de cada espectro. En CV, cada curva seleccionada contiene una única corrida. En las figuras de mezclas, una observación del dataset ancho corresponde a un espectro.

Los conteos se calculan después de seleccionar los datos realmente representados. Se verifica que cada frecuencia EIS tenga el mismo número de contribuyentes. No se suman mediciones de otras condiciones para aumentar `n` y no se interpreta como número de réplicas independientes.

La selección confirmada para el panorama es **sensor A, orden estándar, par P1**. En los archivos recibidos hay **5 barridos por curva** de esa selección, incluido PBS al 60 %. Por eso la leyenda dice `60 % (n = 5)`. El ejemplo de `n = 60` no se fijó manualmente. PBS al 60 % del sensor A tiene 45 espectros si se reúnen todos sus órdenes y pares, pero esa no es la selección confirmada para esta figura.

## Procedencia y cálculo de cada figura

### 1. Voltametrías cíclicas

Entrada: los 24 archivos `CV_<sensor>_E<electrodo>.csv` de `Limpieza_CV/Limpieza_final/`.

Se reutiliza sin cambiar su lógica `leer_csv_cv` de `CV_Grafs_paneles.ipynb`, que lee la exportación UTF-16 de PalmSens y separa los barridos. Se toma el mayor número de barrido presente en cada archivo: **5 en los 24 casos**. Cada curva usa sus pares de potencial y corriente originales; no se promedia, interpola ni remuestrea. Uno de los archivos tiene 293 puntos frente a 295 en la mayoría; eso no cambia que sea un único barrido.

La cuadrícula 2 × 2 muestra A, B, C y D, con seis electrodos por panel y límites comunes calculados sobre todas las curvas finales. La leyenda es común: `E1 (n = 1)`, etc. Los colores de electrodos conservan la paleta elegida en el notebook fuente. El pie indica que se muestra la última corrida.

Conteos y archivos exactos: `conteos_CV.csv`.

### 2. Panorama EIS

Entradas: `nacl_long.csv`, `pbs_long.csv` y `kcl_long.csv` de `ML_DataSets/ML_Datasets/`.

Se sigue la preparación del notebook **`EIS_Panorama_and_Repeatability_Final_CENTRADO.ipynb`**: sensor A, orden `standard`, par P1; se excluye Agua en PBS. Se usa la **media aritmética por frecuencia** de magnitud, fase, parte real y parte imaginaria, como en esa versión final. No se utiliza la mediana del notebook anterior `EIS_Resultados.ipynb` ni se mezclan ambos criterios.

- Filas: NaCl, PBS, KCl; una letra por fila.
- Columnas: magnitud `impedance_magnitude_ohm`, fase `phase_deg` y Nyquist `z_real_ohm` frente a `−z_imag_ohm`.
- Frecuencia de referencia en Hz; Bode con frecuencia logarítmica, magnitud logarítmica y fase lineal.
- Frecuencia, magnitud y fase mantienen límites comunes entre soluciones. Nyquist es lineal; NaCl y PBS comparten límites y KCl usa límites propios señalados en la figura.
- Una leyenda por fila compartida entre las tres representaciones; cada porcentaje incluye el `n` real.
- Los porcentajes son diluciones de la solución madre, **no** concentraciones en mM.

Hay seis curvas en NaCl, cinco en PBS y seis en KCl: **17 curvas distintas, cada una con 5 espectros de 41 frecuencias**. Se dibujan las mismas 17 curvas en tres representaciones; no son 51 conjuntos independientes.

Conteos: `conteos_EIS.csv`. Valores medios usados: `medias_EIS_por_frecuencia.csv`.

### 3. Cajas LOCO

**La figura está completa.** Las fuentes proceden del ZIP adicional `ML_Results-20261030T223432Z-1-001.zip`. Se utilizan las configuraciones confirmadas por el usuario, con características Combined y este orden fijo:

- NaCl: PLS optimizado, regresión lineal (OLS) base, Ridge optimizado.
- PBS: Ridge base, PLS base, SVR optimizado.
- KCl: PCA + GPR base, SVR base, PLS base.

No se vuelve a seleccionar el top 3 por error ni se escogen exclusiones favorables. El código lee metadatos para distinguir `leave_one_concentration_out`, Base y Optimizado; convierte nombres de modelos a las etiquetas de la figura y selecciona solo esas configuraciones. La tabla consolidada conserva:

`solution, model, configuration, feature_set, excluded_pct, true_value, predicted_value, observation_id, row_index, target_name, target_units, source_experiment, source_predictions`.

Los valores predichos se copian de `valor_predicho` sin alterarlos. `valor_real` se verifica contra el objetivo y el `row_index` del dataset correspondiente. Cada identificador se vincula al `sample_id` real; se exige que todas las filas de la concentración excluida estén presentes y que los tres modelos compartan exactamente las observaciones. Se verifican los metadatos, las unidades explícitas del objetivo `_mM`, los errores exportados y la ausencia de duplicados.

Los porcentajes de diseño **no se interpretan como mM**. Estos son los niveles realmente evaluados y sus tamaños por caja y modelo:

| Solución | Exclusión (%) | Objetivo nominal (mM) | n por caja y modelo |
|---|---:|---:|---:|
| NaCl | 40 | 61.6 | 180 |
| NaCl | 60 | 92.4 | 185 |
| NaCl | 80 | 123.2 | 180 |
| NaCl | 90 | 138.6 | 180 |
| PBS | 40 | 56.28 de Cl⁻ | 183 |
| PBS | 60 | 84.42 de Cl⁻ | 180 |
| PBS | 80 | 112.56 de Cl⁻ | 180 |
| KCl | 40 | 4 | 180 |
| KCl | 50 | 5 | 180 |
| KCl | 60 | 6 | 180 |
| KCl | 80 | 8 | 180 |

Se muestran **5.964 predicciones en 33 cajas**, sin descartar mediciones ni exclusiones de estos finalistas. Los niveles 20 % y 100 % figuran entre los niveles de desarrollo, pero no son exclusiones LOCO exportadas de estas configuraciones; no se inventan evaluaciones para ellos.

La figura tiene tres paneles (NaCl, PBS y KCl). El eje horizontal contiene las concentraciones nominales reales y, para cada grupo, un segmento discontinuo marca su valor nominal. El eje vertical contiene las predicciones en mM y puede tener diferente escala por solución. Las leyendas identifican modelo y configuración, sin `n` debajo del nombre. El pie informa los conteos por concentración y modelo.

Las cajas muestran cuartiles 25–75, mediana, bigotes de 1.5 IQR y observaciones exteriores. Estos tamaños son observaciones descriptivas, no una declaración de independencia estadística.

El notebook regenera `reporte_predicciones_finalistas.csv` con `consolidar_loco(...)`; después produce la figura y guarda `conteos_LOCO.csv` y `predicciones_LOCO_usadas.csv`. `procedencia_LOCO.csv` permite remontarse al archivo original de cada grupo. La rama de lectura, validación y dibujo fue ejecutada con los datos reales recibidos. `salidas/tablas/verificacion_metricas_LOCO.csv` registra los 33 grupos: sus MAE, RMSE y sesgos se recalcularon y coincidieron con los `metrics.csv` originales; también se guardan mediana y cuartiles de las predicciones.

### 4. Nominal frente a predicha en mezclas

Entradas: `mixed_nacl_kcl_ml_wide.csv`, el diccionario de características de mezclas y los nueve modelos finales que tienen `metadata.json` al lado de su carpeta `models/`.

Se reutilizan las funciones originales de comprobación de metadatos, selección/orden de características y preparación de entradas de `ML_Validacion_Externa_Mezcla_NaCl_KCl.ipynb`. Se usa el preprocesamiento ya guardado en los modelos. No se reentrena, optimiza, añade escalado ni recorta predicciones.

Se conservan los modelos mostrados anteriormente: **NaCl–PLS, PBS–Ridge y KCl–SVR**. Todos los ejes están en mM y cada panel tiene igual escala horizontal y vertical, con identidad visible. El objetivo de PBS se especifica como cloruro nominal aportado por ambas sales. La transparencia permite ver superposición y las formas identifican las mezclas.

| Mezcla | NaCl (mM) | KCl (mM) | Cloruro nominal (mM) | n por modelo |
|---|---:|---:|---:|---:|
| M1 | 30.8 | 8 | 38.8 | 60 |
| M2 | 61.6 | 4 | 65.6 | 60 |
| M3 | 61.6 | 6 | 67.6 | 60 |
| M4 | 92.4 | 4 | 96.4 | 60 |
| M5 | 123.2 | 2 | 125.2 | 60 |

La clave común indica NaCl/KCl y `n = 60` por mezcla y modelo. No se suman las tres familias para ese conteo. Las letras M1–M5 son identificadores gráficos asignados ordenando las composiciones nominales.

Predicciones completas: `predicciones_mezclas.csv`; clave: `clave_mezclas.csv`; modelos, modos y hashes: `modelos_inferencia.json`.

### 5. Mapas de MAE

Se usa la misma tabla de predicciones, con tres modelos por solución. Cada celda es:

`media(abs(predicción individual − objetivo nominal individual))`.

El valor absoluto se toma **antes** de promediar; no se usa el error de la predicción media. Las filas son M1–M5; las columnas mantienen los modelos de la figura de mapas previa. La clave de composiciones es común y cada grupo contiene 60 observaciones. Se conservan barras de color rotuladas y escalas independientes desde cero al máximo de cada solución. Deben compararse los números entre mapas, no solo la intensidad. No se coloca R² ni error firmado en las celdas.

Los objetivos son NaCl para esa familia, KCl para esa familia y cloruro total para PBS. Tabla numérica: `MAE_por_mezcla_modelo.csv`.

## Interpretación y límites

Las figuras describen respuestas y predicciones contra concentraciones nominales. Las mediciones repetidas no son automáticamente preparaciones independientes, y no se calculan intervalos de confianza ni pruebas de significación. La concordancia de modelos PBS al transferirlos a mezclas no demuestra especificidad de cloruro.

Los niveles reales de entrenamiento KCl recuperados anteriormente del GPR son 2, 4, 5, 6, 8 y 10 mM. El campo de metadatos `[20,40,50,60,80,100]` no se interpreta como mM. Aquí los objetivos se verifican contra las columnas nominales del dataset, no contra ese campo.

No se introdujeron cambios en modelos ni valores experimentales para mejorar la apariencia o el error. La figura LOCO utiliza ahora la evidencia de exclusiones reales proporcionada en el segundo ZIP; no se reentrenó ningún modelo.
