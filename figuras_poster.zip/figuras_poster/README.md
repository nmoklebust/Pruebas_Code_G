# Figuras para el póster de resultados

Esta entrega adapta las figuras a un póster de **62 cm de ancho × 91 cm de alto**. Según la última indicación del usuario, las imágenes no incluyen pies ni párrafos explicativos; se aprovecha ese espacio para ampliar las gráficas. EIS y LOCO tienen 34 cm de ancho para mejorar su lectura, manteniendo los tamaños tipográficos acordados.

## Figuras principales generadas

| Figura solicitada | Estado | Archivo |
|---|---|---|
| 1. Voltametrías tras acondicionamiento | Generada desde los CSV originales | `salidas/figuras/01_CV_acondicionamiento.png` |
| 2. Panorama EIS | Generada desde los CSV originales | `salidas/figuras/02_panorama_EIS.png` |
| 3. Cajas LOCO | Generada con las exclusiones reales recibidas | `salidas/figuras/03_cajas_LOCO.png` |
| 4. Nominal frente a predicha en mezclas | Generada con los modelos finales y las mezclas recibidas | `salidas/figuras/04_predicciones_mezclas.png` |
| 5. Mapas de MAE | Generada desde las mismas predicciones de mezclas | `salidas/figuras/05_mapas_MAE.png` |

Las cinco figuras principales se entregan en PNG a 600 dpi y PDF vectorial, sin pies ni texto explicativo debajo. La figura LOCO utiliza predicciones individuales obtenidas al excluir concentraciones, sin sustituirlas por inferencias de los modelos finales ajustados con todos los datos.

El archivo adicional `ML_Results-20261030T223432Z-1-001.zip` aportó las fuentes que faltaban. Para mantener la entrega compacta, `datos_LOCO/` conserva únicamente los 26 experimentos que contienen los nueve finalistas indicados, con sus 104 archivos originales `metadata.json`, `predictions.csv`, `metrics.csv` y `parameters.csv`. No se modificó su contenido. `datos_LOCO/origen_LOCO.json` registra el nombre y SHA-256 del ZIP completo y las huellas de cada archivo conservado. No es necesario el ZIP adicional completo para reproducir estas figuras: las fuentes pertinentes ya están incluidas.

## Contenido de la entrega

- `figuras_poster.ipynb`: notebook ejecutado, con configuración y resultados.
- `ajustes_eis.py`: corrección de fase, repetibilidad con estilos cualitativos y exportaciones Word.
- `codigo_actualizado/CV_Grafs_paneles_corregido.ipynb`: copia del notebook original con la sustitución puntual «magnitud» → «fase» en el título de fase. Sus rutas originales de Drive se conservan; el notebook principal de esta entrega es el flujo portable ejecutado.
- `figuras_poster.py`: funciones de lectura, validación, inferencia y adaptación de formato; lo usa el notebook.
- `datos_LOCO/`: fuentes originales LOCO de los experimentos pertinentes, con trazabilidad al ZIP adicional.
- `reporte_predicciones_finalistas.csv`: tabla normalizada regenerada por el notebook desde esas fuentes.
- `procedencia_LOCO.csv`: relación entre modelo, configuración, exclusión, archivo y huella de origen.
- `Material_Figuras.zip`: copia intacta de su material de entrada. Permite reproducir la entrega sin depender del directorio temporal de esta conversación.
- `requirements.txt`: dependencias utilizadas, incluyendo scikit-learn 1.6.1, que coincide con las exportaciones.
- `salidas/figuras/`: cinco figuras principales y tres figuras EIS adicionales, en PNG a 600 dpi y PDF.
- `salidas/Word/figuras/`: versiones de 16 cm de ancho para la comparación de soluciones y repetibilidad; leyendas de 9 pt.
- `salidas/tablas/`: conteos, medias EIS, predicciones individuales, MAE, dimensiones, estado y manifiesto.
- `requisitos_recibidos.txt`: copia del documento inicial. La actualización posterior del usuario —sin pies, EIS y LOCO más grandes, sin «Escala propia» y sin `n = 1` en CV— prevalece sobre los puntos de formato anteriores.

## Ejecución y rutas

Extraiga todo el paquete y conserve juntos el notebook, el archivo `.py` y `Material_Figuras.zip`. Desde esa carpeta:

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python -m jupyterlab
```

En Windows, active el entorno con `.venv\Scripts\activate`.

Abra `figuras_poster.ipynb` y ejecute todas las celdas. `ROOT = Path.cwd()` debe apuntar a su carpeta. Puede modificarlo para usar otra ubicación o una carpeta de Drive ya montada. El código no monta automáticamente Google Drive ni necesita credenciales adicionales.

La primera ejecución extrae el ZIP en `entradas/Material_Figuras/`. En las siguientes se verifica que los archivos sigan coincidiendo byte a byte con el ZIP; no se sobrescriben entradas alteradas. Los cambios de rutas, dimensiones y fuentes se hacen en la primera celda del notebook. Los resultados se guardan por separado en `salidas/`.

Se usó Python 3.12. El notebook no reentrena ni optimiza modelos. No se instala XGBoost porque ninguno de los nueve modelos finales recibidos lo necesita. Los paquetes numéricos están registrados en el manifiesto; cambios de versiones pueden introducir diferencias numéricas pequeñas.

## Tamaño físico, tipografía y resolución

| Figura | Ancho × alto finales | Resolución solicitada |
|---|---|---|
| CV | 25 × 25 cm | 600 dpi |
| EIS | 34 × 34 cm | 600 dpi |
| LOCO | 34 × 26 cm | 600 dpi |
| Mezclas | 30 × 18 cm | 600 dpi |
| MAE | 30 × 24 cm | 600 dpi |

Se conserva un título principal de **40 pt**, rótulos de ejes de **18 pt**, números de ejes de **12 pt**, anotaciones de **18 pt** y leyendas generales de **18 pt**; las leyendas comparativas EIS se ajustan según el ancho final de Word, letras de panel en negrita de **18 pt**. No se dibujan pies. Los encabezados de columnas EIS son rótulos internos de 18 pt, sin repetir títulos largos en cada panel. Los colores de solución son NaCl azul, PBS verde y KCl naranja; CV utiliza colores fijos por electrodo.

Las figuras se exportan **sin `bbox_inches='tight'`** para no alterar su tamaño físico. La relación es `píxeles = cm / 2.54 × 600`, con el redondeo de la exportación. `dimensiones_exportaciones.csv` informa dimensiones y píxeles efectivamente guardados, además de los dpi leídos del PNG. Una diferencia inferior a un píxel por redondeo no altera la escala de impresión de forma significativa.

No reduzca posteriormente las imágenes si necesita conservar la tipografía indicada: reducir el tamaño impreso también reduce los puntos tipográficos. Cambie `dimensiones_cm` en el notebook y vuelva a exportar. La elección de dimensiones de cada figura no es una maquetación completa del póster: todavía debe reservarse espacio para título, texto, márgenes y otros contenidos.

## Qué significa `n`

`n` es el número de **barridos completos distintos** que aportan a cada línea o distribución. En EIS se cuenta `sample_id`, no las 41 filas de frecuencia de cada espectro. En CV, cada curva seleccionada contiene una única corrida. En las figuras de mezclas, una observación del dataset ancho corresponde a un espectro.

Los conteos se calculan después de seleccionar los datos realmente representados. Se verifica que cada frecuencia EIS tenga el mismo número de contribuyentes. No se suman mediciones de otras condiciones para aumentar `n` y no se interpreta como número de réplicas independientes.

La selección actual del panorama incluye **todos los sensores A–D y pares P1–P3, únicamente en el orden estándar**. Cada espectro aporta el mismo peso al promedio por frecuencia; no hay un promedio previo por sensor. La mayoría de las curvas usa `n = 60`; las excepciones son NaCl al 60 % (`n = 65`), PBS al 20 % (`n = 59`) y KCl al 100 % (`n = 59`). Los conteos se obtienen de los espectros disponibles, sin equilibrar ni completar artificialmente los grupos.

## Procedencia y cálculo de cada figura

### 1. Voltametrías cíclicas

Entrada: los 24 archivos `CV_<sensor>_E<electrodo>.csv` de `Limpieza_CV/Limpieza_final/`.

Se reutiliza sin cambiar su lógica `leer_csv_cv` de `CV_Grafs_paneles.ipynb`, que lee la exportación UTF-16 de PalmSens y separa los barridos. Se toma el mayor número de barrido presente en cada archivo: **5 en los 24 casos**. Cada curva usa sus pares de potencial y corriente originales; no se promedia, interpola ni remuestrea. Uno de los archivos tiene 293 puntos frente a 295 en la mayoría; eso no cambia que sea un único barrido.

La cuadrícula 2 × 2 muestra A, B, C y D, con seis electrodos por panel y límites comunes calculados sobre todas las curvas finales. La leyenda común identifica únicamente E1–E6, sin `n = 1`. Los colores de electrodos conservan la paleta elegida en el notebook fuente. La selección del último barrido queda documentada aquí y en `conteos_CV.csv`, sin añadir un pie a la imagen.

Conteos y archivos exactos: `conteos_CV.csv`.

### 2. Panorama EIS

Entradas: `nacl_long.csv`, `pbs_long.csv` y `kcl_long.csv` de `ML_DataSets/ML_Datasets/`.

Se conserva el cálculo de **media aritmética por frecuencia** del notebook `EIS_Panorama_and_Repeatability_Final_CENTRADO.ipynb`, con la agrupación actualizada según la última indicación del usuario:

1. Seleccionar `measurement_order == "standard"`, sensores A–D y pares P1–P3, incluyendo todos sus barridos disponibles. Se mantiene la exclusión de Agua en PBS.
2. Separar por solución y concentración; en estos CSV cada `dilution_percent` corresponde a un único objetivo nominal, lo que se verifica antes de promediar.
3. Agrupar por `frequency_reference_hz` y aplicar una media aritmética directa sobre los espectros disponibles, para cada variable.

**No se calculan promedios por sensor para luego promediarlos**. Cada espectro tiene un valor por frecuencia y participa con el mismo peso. Si un sensor tiene más barridos, aporta más observaciones al promedio; no se iguala artificialmente el peso de los sensores. Los órdenes inverso y aleatorio no participan.

- Filas: NaCl, PBS, KCl; una letra por fila.
- Columnas: magnitud `impedance_magnitude_ohm`, fase `phase_deg` y Nyquist, con las medias independientes de `z_real_ohm` y `z_imag_ohm`, representadas como Z′ frente a −Z″.
- La magnitud y la fase se promedian directamente desde sus columnas, sin recalcularlas a partir de una impedancia compleja media. No se usa la mediana ni un promedio circular de fase.
- Frecuencia de referencia en Hz; Bode con frecuencia logarítmica, magnitud logarítmica y fase lineal.
- Frecuencia, magnitud y fase mantienen límites comunes entre soluciones, recalculados a partir de los nuevos promedios. Nyquist es lineal; NaCl y PBS comparten límites y KCl usa límites propios, sin la anotación «Escala propia».
- Una leyenda por fila compartida entre las tres representaciones; cada porcentaje incluye el `n` real. Se conserva la presentación ampliada de 34 × 34 cm, sin pie explicativo.
- Los porcentajes son diluciones de la solución madre, **no** concentraciones en mM.

| Solución | Dilución (%) | n de espectros por curva |
|---|---|---|
| NaCl | 20, 40, 80, 90, 100 | 60 en cada una |
| NaCl | 60 | 65 |
| PBS | 20 | 59 |
| PBS | 40, 60, 80, 100 | 60 en cada una |
| KCl | 20, 40, 50, 60, 80 | 60 en cada una |
| KCl | 100 | 59 |

Se utilizan **1.023 espectros**, cada uno con 41 frecuencias: 365 de NaCl, 299 de PBS y 359 de KCl. Hay seis curvas NaCl, cinco PBS y seis KCl, es decir, **17 curvas de concentración**. Se dibujan los mismos conjuntos en tres representaciones; no se cuentan como 51 conjuntos independientes.

Archivos de auditoría:

- `conteos_EIS.csv`: conteos por solución y dilución, objetivo nominal, sensores, pares y frecuencias.
- `barridos_EIS_usados.csv`: identidad y metadatos de los 1.023 espectros seleccionados.
- `conteos_EIS_por_sensor_par.csv`: número de barridos de cada sensor y par dentro de cada concentración.
- `medias_EIS_por_frecuencia.csv`: los cuatro promedios utilizados en cada uno de los 697 puntos de concentración/frecuencia (17 × 41).

### 3. Cajas LOCO

**La figura está completa.** Las fuentes proceden del ZIP adicional `ML_Results-20261030T223432Z-1-001.zip`. Se utilizan las configuraciones confirmadas por el usuario, con características Combined y este orden fijo:

- NaCl: PLS optimizado, regresión lineal (OLS) base, Ridge optimizado.
- PBS: Ridge base, PLS base, SVR optimizado.
- KCl: PCA + GPR base, SVR base, PLS base.

No se vuelve a seleccionar el top 3 por error ni se escogen exclusiones favorables. El código lee metadatos para distinguir `leave_one_concentration_out`, Base y Optimizado; convierte nombres de modelos a las etiquetas de la figura y selecciona solo esas configuraciones. La tabla consolidada conserva:

`solution, model, configuration, feature_set, excluded_pct, true_value, predicted_value, observation_id, row_index, target_name, target_units, source_experiment, source_predictions`.

Los valores predichos se copian de `valor_predicho` sin alterarlos. `valor_real` se verifica contra el objetivo y el `row_index` del dataset correspondiente. Cada identificador se vincula al `sample_id` real; se exige que todas las filas de la concentración excluida estén presentes y que los tres modelos compartan exactamente las observaciones. Se verifican los metadatos, las unidades explícitas del objetivo `_mM`, los errores exportados y la ausencia de duplicados.

Los porcentajes de diseño **no se interpretan como mM**. Estos son los niveles realmente evaluados y sus tamaños por caja y modelo:

| Solución | Exclusión (%) | Objetivo nominal (mM) | n por caja y modelo |
|---|---:|---:|---:|
| NaCl | 40 | 61.6 | 180 |
| NaCl | 60 | 92.4 | 185 |
| NaCl | 80 | 123.2 | 180 |
| NaCl | 90 | 138.6 | 180 |
| PBS | 40 | 56.28 de Cl⁻ | 183 |
| PBS | 60 | 84.42 de Cl⁻ | 180 |
| PBS | 80 | 112.56 de Cl⁻ | 180 |
| KCl | 40 | 4 | 180 |
| KCl | 50 | 5 | 180 |
| KCl | 60 | 6 | 180 |
| KCl | 80 | 8 | 180 |

Se muestran **5.964 predicciones en 33 cajas**, sin descartar mediciones ni exclusiones de estos finalistas. Los niveles 20 % y 100 % figuran entre los niveles de desarrollo, pero no son exclusiones LOCO exportadas de estas configuraciones; no se inventan evaluaciones para ellos.

La figura tiene tres paneles (NaCl, PBS y KCl). El eje horizontal contiene las concentraciones nominales reales y, para cada grupo, un segmento discontinuo marca su valor nominal. El eje vertical contiene las predicciones en mM y puede tener diferente escala por solución. Las leyendas identifican modelo y configuración, sin `n` debajo del nombre. Los conteos por concentración y modelo se conservan en `conteos_LOCO.csv` y en la tabla de este README; no se añade un pie a la imagen. El espacio liberado se utiliza para ampliar las cajas y el área de trazado.

Las cajas muestran cuartiles 25–75, mediana, bigotes de 1.5 IQR y observaciones exteriores. Estos tamaños son observaciones descriptivas, no una declaración de independencia estadística.

El notebook regenera `reporte_predicciones_finalistas.csv` con `consolidar_loco(...)`; después produce la figura y guarda `conteos_LOCO.csv` y `predicciones_LOCO_usadas.csv`. `procedencia_LOCO.csv` permite remontarse al archivo original de cada grupo. La rama de lectura, validación y dibujo fue ejecutada con los datos reales recibidos. `salidas/tablas/verificacion_metricas_LOCO.csv` registra los 33 grupos: sus MAE, RMSE y sesgos se recalcularon y coincidieron con los `metrics.csv` originales; también se guardan mediana y cuartiles de las predicciones.

### 4. Nominal frente a predicha en mezclas

Entradas: `mixed_nacl_kcl_ml_wide.csv`, el diccionario de características de mezclas y los nueve modelos finales que tienen `metadata.json` al lado de su carpeta `models/`.

Se reutilizan las funciones originales de comprobación de metadatos, selección/orden de características y preparación de entradas de `ML_Validacion_Externa_Mezcla_NaCl_KCl.ipynb`. Se usa el preprocesamiento ya guardado en los modelos. No se reentrena, optimiza, añade escalado ni recorta predicciones.

Se conservan los modelos mostrados anteriormente: **NaCl–PLS, PBS–Ridge y KCl–SVR**. Todos los ejes están en mM y cada panel tiene igual escala horizontal y vertical, con identidad visible. El objetivo de PBS se especifica como cloruro nominal aportado por ambas sales. La transparencia permite ver superposición y las formas identifican las mezclas.

| Mezcla | NaCl (mM) | KCl (mM) | Cloruro nominal (mM) | n por modelo |
|---|---:|---:|---:|---:|
| M1 | 30.8 | 8 | 38.8 | 60 |
| M2 | 61.6 | 4 | 65.6 | 60 |
| M3 | 61.6 | 6 | 67.6 | 60 |
| M4 | 92.4 | 4 | 96.4 | 60 |
| M5 | 123.2 | 2 | 125.2 | 60 |

La leyenda común se titula «Mezclas: NaCl/KCl (mM)» e indica `n = 60` por mezcla y modelo. Los modelos seleccionados aparecen como subtítulos breves dentro de cada panel, porque ya no hay pie explicativo. No se suman las tres familias para ese conteo. Las letras M1–M5 son identificadores gráficos asignados ordenando las composiciones nominales.

Predicciones completas: `predicciones_mezclas.csv`; clave: `clave_mezclas.csv`; modelos, modos y hashes: `modelos_inferencia.json`.

### 5. Mapas de MAE

Se usa la misma tabla de predicciones, con tres modelos por solución. Cada celda es:

`media(abs(predicción individual − objetivo nominal individual))`.

El valor absoluto se toma **antes** de promediar; no se usa el error de la predicción media. Las filas son M1–M5; las columnas mantienen los modelos de la figura de mapas previa. La clave de composiciones es común y cada grupo contiene 60 observaciones. Se conservan barras de color rotuladas y escalas independientes desde cero al máximo de cada solución. Deben compararse los números entre mapas, no solo la intensidad. No se coloca R² ni error firmado en las celdas.

Los objetivos son NaCl para esa familia, KCl para esa familia y cloruro total para PBS. Tabla numérica: `MAE_por_mezcla_modelo.csv`.

## Interpretación y límites

Las figuras describen respuestas y predicciones contra concentraciones nominales. Las mediciones repetidas no son automáticamente preparaciones independientes, y no se calculan intervalos de confianza ni pruebas de significación. La concordancia de modelos PBS al transferirlos a mezclas no demuestra especificidad de cloruro.

Los niveles reales de entrenamiento KCl recuperados anteriormente del GPR son 2, 4, 5, 6, 8 y 10 mM. El campo de metadatos `[20,40,50,60,80,100]` no se interpreta como mM. Aquí los objetivos se verifican contra las columnas nominales del dataset, no contra ese campo.

No se introdujeron cambios en modelos ni valores experimentales para mejorar la apariencia o el error. La figura LOCO utiliza ahora la evidencia de exclusiones reales proporcionada en el segundo ZIP; no se reentrenó ningún modelo.


## Cambios de presentación de esta versión

Se retiraron los cinco pies y sus archivos de texto de la entrega. Se conserva el formato sin pies y la mayor área de trazado. En la actualización de agrupación EIS cambian únicamente los espectros seleccionados para esa figura y sus promedios, conteos y límites derivados; los modelos, las predicciones, los errores y las otras cuatro figuras permanecen iguales. La documentación detallada permanece en este README; las imágenes contienen únicamente títulos, ejes, unidades, identificadores, leyendas y referencias necesarias.


La agrupación EIS actual reemplaza la selección anterior de sensor A y par P1. La instrucción más reciente del usuario se aplica tanto al notebook como al módulo de cálculo y a sus tablas de auditoría.


## Ajustes solicitados para el documento Word

### Título de fase en las figuras que acompañan a CV

`salidas/figuras/06_Bode_fase_CV_cuatro_sensores.png` y su PDF muestran el título corregido:

**Comparación de diagramas de fase de Bode entre sensores**.

La figura usa las 24 exportaciones originales `EIS_<sensor>_E<electrodo>.csv` de `Limpieza_CV/Limpieza_final/EIS_Limpieza/`. Se reutilizan las funciones originales `normalizar_encabezado`, `identificar_columnas` y `leer_csv_eis` del notebook de CV, incluida la conversión de «neg. Phase» a fase. Se conservan los colores de los seis electrodos, sus mediciones y los límites compartidos. El formato sigue el panel fuente de 16 × 11 pulgadas (40.64 × 27.94 cm), con título de 23 pt; no se sustituye por un gráfico de magnitud.

El notebook original con el cambio de una palabra se incluye en `codigo_actualizado/`. Sus salidas antiguas se eliminaron para que no aparezca el título erróneo guardado. Esa copia no fue ejecutada con sus rutas de Drive; la figura entregada se genera en el notebook principal mediante `ajustes_eis.py`, con las mismas funciones de lectura y los archivos recibidos.

Los valores efectivamente representados se conservan en `salidas/tablas/EIS_acondicionamiento_usado.csv`.

### Leyendas comparativas a aproximadamente 9 pt en Word

La respuesta del usuario fue «al ancho de una página completa más o menos». Se toma **16 cm de ancho útil** como referencia configurable, sin asumir que se haya medido el documento. En la primera celda del notebook:

```python
"ancho_insercion_word_cm": 16.0,
"leyenda_word_pt": 9.0,
```

La versión grande de EIS, de 34 cm de ancho, utiliza:

`puntos de leyenda exportados = 9 × 34 / 16 = 19.125 pt`.

Al insertar esa imagen a 16 cm de ancho, la leyenda equivale a 9 pt. Si Word utiliza otro ancho, los puntos finales cambian proporcionalmente: introduzca ese ancho en la configuración y vuelva a ejecutar.

Para evitar depender de un redimensionado posterior, `salidas/Word/figuras/` contiene exportaciones generadas directamente a **16 × 20 cm, 600 dpi**, con leyendas físicas de **9 pt**, ejes de 9 pt y números de 8 pt. No se redimensionan capturas ni imágenes ya rasterizadas. Inserte estas imágenes a **16 cm de ancho**, sin estirarlas o comprimirlas verticalmente. Word puede ignorar el tamaño físico del PNG, por lo que debe comprobarse el ancho de inserción en el documento.

| Archivo en `salidas/Word/figuras/` | Contenido |
|---|---|
| `02_panorama_EIS.png` / `.pdf` | NaCl, PBS y KCl; promedio directo del orden estándar A–D, P1–P3; conteos reales conservados |
| `07_repetibilidad_EIS_logaritmica.png` / `.pdf` | Barridos, pares y sensores; Bode con frecuencia/magnitud logarítmicas |
| `08_repetibilidad_EIS_lineal.png` / `.pdf` | Los mismos datos y estilos; Bode lineal |

Hay una sola leyenda compartida por fila. Se reservan bandas específicas para las leyendas; sus conteos `n` no se eliminan. Las versiones grandes de repetibilidad también se guardan en `salidas/figuras/` a 34 × 34 cm. Los registros de dimensiones y puntos están en `salidas/tablas/dimensiones_exportaciones.csv` y `salidas/Word/dimensiones_exportaciones.csv`.

### Repetibilidad del par P1, otros pares y otros sensores

Se conserva la selección del notebook `EIS_Panorama_and_Repeatability_Final_CENTRADO.ipynb`: **NaCl al 80 %, orden estándar**, con sensor A y par P1 como referencia. La selección se puede cambiar en `SELECCION_REPETIBILIDAD` dentro del notebook principal.

| Fila | Qué representa cada curva | Etiquetas actuales |
|---|---|---|
| (a) Barridos | Un espectro original del sensor A, P1 | Barrido 1, Barrido 2, Barrido 3, Barrido 4, Barrido 5; sin n |
| (b) Pares | Media aritmética directa por frecuencia de las repeticiones de cada par del sensor A | Par P1 (n = 5), Par P2 (n = 5), Par P3 (n = 5) |
| (c) Sensores | Media aritmética directa por frecuencia de todos los pares y barridos de cada sensor | Sensor A (n = 15), Sensor B (n = 15), Sensor C (n = 15), Sensor D (n = 15) |

Los números de barrido proceden de `repetition`, no de una renumeración arbitraria. Los conteos se calculan con `sample_id` y se verifica que cada frecuencia tenga el mismo número de contribuyentes. No se mezclan los órdenes inverso o aleatorio.

La paleta es **cualitativa**: azul, naranja, verde, rosa/morado y violeta oscuro, complementada con trazos continuo, discontinuo, raya-punto, punteado y un patrón compuesto. Cada identidad mantiene exactamente su color y patrón entre magnitud, fase y Nyquist, y entre las versiones lineal y logarítmica. No se usan intensidades de azul como única forma de distinguir las curvas.

Los promedios son por variable y por frecuencia, sin recalcular fase o magnitud a partir de la impedancia media. Los límites son comunes entre filas de la misma representación. En el intervalo estrecho de magnitud se utilizan marcas numéricas legibles, manteniendo la escala logarítmica en la versión correspondiente.

Archivos de trazabilidad:

- `conteos_repetibilidad_EIS.csv`: etiquetas, conteos, colores y patrones por identidad.
- `curvas_repetibilidad_EIS.csv`: valores individuales o promedios representados.
- `barridos_repetibilidad_EIS.csv`: los espectros que aportan a la selección.

Las mediciones repetidas se siguen tratando como observaciones descriptivas. Estos ajustes no cambian los modelos, las predicciones de mezclas ni la evaluación LOCO. Las nuevas curvas de repetibilidad son visualizaciones de mediciones EIS existentes.
