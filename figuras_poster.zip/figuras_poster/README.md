# Figuras para el póster de resultados

Esta entrega adapta el formato de las figuras solicitadas a un póster de **62 cm de ancho × 91 cm de alto**, manteniendo los tamaños tipográficos del documento y, según la aclaración recibida, utilizando 25–30 cm de ancho en las figuras densas.

## Qué está generado y qué falta

| Figura solicitada | Estado | Archivo |
|---|---|---|
| 1. Voltametrías tras acondicionamiento | Generada desde los CSV originales | `salidas/figuras/01_CV_acondicionamiento.png` |
| 2. Panorama EIS | Generada desde los CSV originales | `salidas/figuras/02_panorama_EIS.png` |
| 3. Cajas LOCO | **Pendiente de predicciones individuales LOCO** | Se registra en `salidas/PENDIENTE_LOCO.txt` |
| 4. Nominal frente a predicha en mezclas | Generada con los modelos finales y las mezclas recibidas | `salidas/figuras/04_predicciones_mezclas.png` |
| 5. Mapas de MAE | Generada desde las mismas predicciones de mezclas | `salidas/figuras/05_mapas_MAE.png` |

Cada figura disponible también tiene PDF vectorial y su pie explicativo en un archivo de texto separado. **No se ha completado la figura LOCO con datos inventados ni con predicciones de modelos ajustados sobre todo el dataset.**

El ZIP recibido no contiene `predictions.csv` de experimentos LOCO ni `reporte_predicciones_finalistas.csv`. El notebook `EIS_Resultados_ML_Tesis_final.ipynb` sí contiene código y salidas visuales de esos análisis, pero lee los resultados individuales desde una carpeta de Drive no incluida. Sus tablas de pantalla y gráficos guardados no proporcionan todas las observaciones necesarias para reconstruir cajas y bigotes fielmente.

Para terminar la figura 3, aporte `reporte_predicciones_finalistas.csv`, exportado por ese notebook con **todas** las exclusiones evaluadas. Puede colocarlo junto a `figuras_poster.ipynb` y volver a ejecutar. Otra opción es aportar los experimentos originales con sus `predictions.csv` y `metadata.json`; esos resultados requieren primero consolidarse con el notebook original. No hace falta volver a entrenar los modelos finales para las otras cuatro figuras.

## Contenido de la entrega

- `figuras_poster.ipynb`: notebook ejecutado, con configuración y resultados.
- `figuras_poster.py`: funciones de lectura, validación, inferencia y adaptación de formato; lo usa el notebook.
- `Material_Figuras.zip`: copia intacta de su material de entrada. Permite reproducir la entrega sin depender del directorio temporal de esta conversación.
- `requirements.txt`: dependencias utilizadas, incluyendo scikit-learn 1.6.1, que coincide con las exportaciones.
- `salidas/figuras/`: PNG a 600 dpi y PDF al mismo tamaño físico.
- `salidas/pies/`: pies incluidos en las imágenes, también como texto reutilizable en el póster.
- `salidas/tablas/`: conteos, medias EIS, predicciones individuales, MAE, dimensiones, estado y manifiesto.
- `requisitos_recibidos.txt`: copia de las instrucciones de formato aportadas.

## Ejecución y rutas

Extraiga todo el paquete y conserve juntos el notebook, el archivo `.py` y `Material_Figuras.zip`. Desde esa carpeta:

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python -m jupyterlab
```

En Windows, active el entorno con `.venv\Scripts\activate`.

Abra `figuras_poster.ipynb` y ejecute todas las celdas. `ROOT = Path.cwd()` debe apuntar a su carpeta. Puede modificarlo para usar otra ubicación o una carpeta de Drive ya montada. El código no monta automáticamente Google Drive ni necesita credenciales adicionales.

La primera ejecución extrae el ZIP en `entradas/Material_Figuras/`. En las siguientes se verifica que los archivos sigan coincidiendo byte a byte con el ZIP; no se sobrescriben entradas alteradas. Los cambios de rutas, dimensiones y fuentes se hacen en la primera celda del notebook. Los resultados se guardan por separado en `salidas/`.

Se usó Python 3.12. El notebook no reentrena ni optimiza modelos. No se instala XGBoost porque ninguno de los nueve modelos finales recibidos lo necesita. Los paquetes numéricos están registrados en el manifiesto; cambios de versiones pueden introducir diferencias numéricas pequeñas.

## Tamaño físico, tipografía y resolución

| Figura | Ancho × alto finales | Resolución solicitada |
|---|---|---|
| CV | 25 × 25 cm | 600 dpi |
| EIS | 30 × 32 cm | 600 dpi |
| LOCO, cuando haya datos | 30 × 26 cm | 600 dpi |
| Mezclas | 30 × 22 cm | 600 dpi |
| MAE | 30 × 26 cm | 600 dpi |

Se conserva un título principal de **40 pt**, rótulos de ejes de **18 pt**, números de ejes de **12 pt**, leyendas y anotaciones de **18 pt**, letras de panel en negrita de **18 pt** y pies de **18 pt**. Los encabezados de columnas EIS son rótulos internos de 18 pt, sin repetir títulos largos en cada panel. Los colores de solución son NaCl azul, PBS verde y KCl naranja; CV utiliza colores fijos por electrodo.

Las figuras se exportan **sin `bbox_inches='tight'`** para no alterar su tamaño físico. La relación es `píxeles = cm / 2.54 × 600`, con el redondeo de la exportación. `dimensiones_exportaciones.csv` informa dimensiones y píxeles efectivamente guardados, además de los dpi leídos del PNG. Una diferencia inferior a un píxel por redondeo no altera la escala de impresión de forma significativa.

No reduzca posteriormente las imágenes si necesita conservar la tipografía indicada: reducir el tamaño impreso también reduce los puntos tipográficos. Cambie `dimensiones_cm` en el notebook y vuelva a exportar. La elección de dimensiones de cada figura no es una maquetación completa del póster: todavía debe reservarse espacio para título, texto, márgenes y otros contenidos.

## Qué significa `n`

`n` es el número de **barridos completos distintos** que aportan a cada línea o distribución. En EIS se cuenta `sample_id`, no las 41 filas de frecuencia de cada espectro. En CV, cada curva seleccionada contiene una única corrida. En las figuras de mezclas, una observación del dataset ancho corresponde a un espectro.

Los conteos se calculan después de seleccionar los datos realmente representados. Se verifica que cada frecuencia EIS tenga el mismo número de contribuyentes. No se suman mediciones de otras condiciones para aumentar `n` y no se interpreta como número de réplicas independientes.

La selección confirmada para el panorama es **sensor A, orden estándar, par P1**. En los archivos recibidos hay **5 barridos por curva** de esa selección, incluido PBS al 60 %. Por eso la leyenda dice `60 % (n = 5)`. El ejemplo de `n = 60` no se fijó manualmente. PBS al 60 % del sensor A tiene 45 espectros si se reúnen todos sus órdenes y pares, pero esa no es la selección confirmada para esta figura.

## Procedencia y cálculo de cada figura

### 1. Voltametrías cíclicas

Entrada: los 24 archivos `CV_<sensor>_E<electrodo>.csv` de `Limpieza_CV/Limpieza_final/`.

Se reutiliza sin cambiar su lógica `leer_csv_cv` de `CV_Grafs_paneles.ipynb`, que lee la exportación UTF-16 de PalmSens y separa los barridos. Se toma el mayor número de barrido presente en cada archivo: **5 en los 24 casos**. Cada curva usa sus pares de potencial y corriente originales; no se promedia, interpola ni remuestrea. Uno de los archivos tiene 293 puntos frente a 295 en la mayoría; eso no cambia que sea un único barrido.

La cuadrícula 2 × 2 muestra A, B, C y D, con seis electrodos por panel y límites comunes calculados sobre todas las curvas finales. La leyenda es común: `E1 (n = 1)`, etc. Los colores de electrodos conservan la paleta elegida en el notebook fuente. El pie indica que se muestra la última corrida.

Conteos y archivos exactos: `conteos_CV.csv`.

### 2. Panorama EIS

Entradas: `nacl_long.csv`, `pbs_long.csv` y `kcl_long.csv` de `ML_DataSets/ML_Datasets/`.

Se sigue la preparación del notebook **`EIS_Panorama_and_Repeatability_Final_CENTRADO.ipynb`**: sensor A, orden `standard`, par P1; se excluye Agua en PBS. Se usa la **media aritmética por frecuencia** de magnitud, fase, parte real y parte imaginaria, como en esa versión final. No se utiliza la mediana del notebook anterior `EIS_Resultados.ipynb` ni se mezclan ambos criterios.

- Filas: NaCl, PBS, KCl; una letra por fila.
- Columnas: magnitud `impedance_magnitude_ohm`, fase `phase_deg` y Nyquist `z_real_ohm` frente a `−z_imag_ohm`.
- Frecuencia de referencia en Hz; Bode con frecuencia logarítmica, magnitud logarítmica y fase lineal.
- Frecuencia, magnitud y fase mantienen límites comunes entre soluciones. Nyquist es lineal; NaCl y PBS comparten límites y KCl usa límites propios señalados en la figura.
- Una leyenda por fila compartida entre las tres representaciones; cada porcentaje incluye el `n` real.
- Los porcentajes son diluciones de la solución madre, **no** concentraciones en mM.

Hay seis curvas en NaCl, cinco en PBS y seis en KCl: **17 curvas distintas, cada una con 5 espectros de 41 frecuencias**. Se dibujan las mismas 17 curvas en tres representaciones; no son 51 conjuntos independientes.

Conteos: `conteos_EIS.csv`. Valores medios usados: `medias_EIS_por_frecuencia.csv`.

### 3. Cajas LOCO

Pendiente: faltan las predicciones individuales. No se aplican los modelos finales a los datos de entrenamiento para generar una sustitución, porque eso no sería una evaluación dejando una concentración fuera.

El lector preparado acepta la tabla consolidada original con:

`solution, model, configuration, feature_set, excluded_pct, true_value, predicted_value, observation_id`.

Los valores `true_value` y `predicted_value` deben estar expresados en mM, como en la salida normalizada del notebook recibido. `excluded_pct` identifica el grupo de diseño y **no se usa como concentración mM**. Se conservan las configuraciones finalistas recogidas por ese notebook:

- NaCl: PLS optimizado, regresión lineal base, Ridge optimizado.
- PBS: Ridge base, PLS base, SVR optimizado.
- KCl: PCA + GPR base, SVR base, PLS base.

Todos usan el conjunto Combined. Se mantiene ese orden y se exige cobertura de las mismas observaciones en cada exclusión. Se conservan todas las exclusiones recibidas de los finalistas, no solo las de menor error ni solo las interiores. Una exclusión ausente en todos los archivos no se puede detectar sin el plan original; por eso debe aportarse la exportación completa.

La figura preparada usa tres paneles, etiquetas nominales reales y un segmento discontinuo al valor nominal de cada grupo. Las cajas muestran cuartiles 25–75, mediana, bigotes de 1.5 IQR y observaciones exteriores. Los conteos se informan en el pie por grupo, no debajo de nombres de modelos. Si son diferentes por modelo, se indican en el orden fijo de la leyenda.

La rama de lectura y dibujo LOCO todavía **no ha sido validada con sus datos reales**, porque no están en el ZIP. No se afirma que esa figura esté terminada.

### 4. Nominal frente a predicha en mezclas

Entradas: `mixed_nacl_kcl_ml_wide.csv`, el diccionario de características de mezclas y los nueve modelos finales que tienen `metadata.json` al lado de su carpeta `models/`.

Se reutilizan las funciones originales de comprobación de metadatos, selección/orden de características y preparación de entradas de `ML_Validacion_Externa_Mezcla_NaCl_KCl.ipynb`. Se usa el preprocesamiento ya guardado en los modelos. No se reentrena, optimiza, añade escalado ni recorta predicciones.

Se conservan los modelos mostrados anteriormente: **NaCl–PLS, PBS–Ridge y KCl–SVR**. Todos los ejes están en mM y cada panel tiene igual escala horizontal y vertical, con identidad visible. El objetivo de PBS se especifica como cloruro nominal aportado por ambas sales. La transparencia permite ver superposición y las formas identifican las mezclas.

| Mezcla | NaCl (mM) | KCl (mM) | Cloruro nominal (mM) | n por modelo |
|---|---:|---:|---:|---:|
| M1 | 30.8 | 8 | 38.8 | 60 |
| M2 | 61.6 | 4 | 65.6 | 60 |
| M3 | 61.6 | 6 | 67.6 | 60 |
| M4 | 92.4 | 4 | 96.4 | 60 |
| M5 | 123.2 | 2 | 125.2 | 60 |

La clave común indica NaCl/KCl y `n = 60` por mezcla y modelo. No se suman las tres familias para ese conteo. Las letras M1–M5 son identificadores gráficos asignados ordenando las composiciones nominales.

Predicciones completas: `predicciones_mezclas.csv`; clave: `clave_mezclas.csv`; modelos, modos y hashes: `modelos_inferencia.json`.

### 5. Mapas de MAE

Se usa la misma tabla de predicciones, con tres modelos por solución. Cada celda es:

`media(abs(predicción individual − objetivo nominal individual))`.

El valor absoluto se toma **antes** de promediar; no se usa el error de la predicción media. Las filas son M1–M5; las columnas mantienen los modelos de la figura de mapas previa. La clave de composiciones es común y cada grupo contiene 60 observaciones. Se conservan barras de color rotuladas y escalas independientes desde cero al máximo de cada solución. Deben compararse los números entre mapas, no solo la intensidad. No se coloca R² ni error firmado en las celdas.

Los objetivos son NaCl para esa familia, KCl para esa familia y cloruro total para PBS. Tabla numérica: `MAE_por_mezcla_modelo.csv`.

## Interpretación y límites

Las figuras describen respuestas y predicciones contra concentraciones nominales. Las mediciones repetidas no son automáticamente preparaciones independientes, y no se calculan intervalos de confianza ni pruebas de significación. La concordancia de modelos PBS al transferirlos a mezclas no demuestra especificidad de cloruro.

Los niveles reales de entrenamiento KCl recuperados anteriormente del GPR son 2, 4, 5, 6, 8 y 10 mM. El campo de metadatos `[20,40,50,60,80,100]` no se interpreta como mM. Aquí los objetivos se verifican contra las columnas nominales del dataset, no contra ese campo.

No se introdujeron cambios en modelos ni valores experimentales para mejorar la apariencia o el error. La figura LOCO solo se podrá completar con su evidencia de evaluación real.
