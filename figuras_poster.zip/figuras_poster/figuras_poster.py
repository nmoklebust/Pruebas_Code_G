"""Datos y figuras del póster. Los algoritmos originales no se reentrenan."""
from pathlib import Path, PurePosixPath
import ast
import csv
import gc
import hashlib
import json
import re
import textwrap
import zipfile
import numpy as np
import pandas as pd
import joblib
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.colors import LinearSegmentedColormap
from matplotlib.ticker import FuncFormatter
from PIL import Image
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

SOLUCIONES = ['NaCl', 'PBS', 'KCl']
COLORES = {'NaCl':'#0072B2','PBS':'#009E73','KCl':'#D55E00'}
MARCADORES = ['o','s','^','D','P']
ETIQUETAS_MODELO = {'Linear_Regression':'Regresión lineal','PLS_Regression':'PLS',
    'Ridge_Regression':'Ridge','SVR_RBF':'SVR (RBF)','PCA___GPR':'PCA + GPR'}
OBJETIVOS = {'NaCl':'nominal_nacl_mM','KCl':'nominal_kcl_mM','PBS':'nominal_chloride_from_nacl_kcl_mM'}
MODELOS_MEZCLAS = {'NaCl':['Linear_Regression','PLS_Regression','Ridge_Regression'],
                  'PBS':['PLS_Regression','Ridge_Regression','SVR_RBF'],
                  'KCl':['PLS_Regression','SVR_RBF','PCA___GPR']}
SELECCIONADOS = {'NaCl':'PLS_Regression','KCl':'SVR_RBF','PBS':'Ridge_Regression'}
# Finalistas y orden confirmados por el usuario; coinciden con el notebook recibido.
FINALISTAS_LOCO = {'NaCl':[('PLS','Optimizado'),('OLS','Base'),('Ridge','Optimizado')],
                  'PBS':[('Ridge','Base'),('PLS','Base'),('SVR','Optimizado')],
                  'KCl':[('GPR-PCA','Base'),('SVR','Base'),('PLS','Base')]}


def extraer(archivo, destino):
    destino = Path(destino)
    with zipfile.ZipFile(archivo) as z:
        for info in z.infolist():
            ruta=PurePosixPath(info.filename)
            if ruta.is_absolute() or '..' in ruta.parts:
                raise ValueError('Ruta no segura en el ZIP')
        if not destino.exists():
            z.extractall(destino)
        # No sobrescribe entradas alteradas: exige que se investiguen las diferencias.
        for info in z.infolist():
            if not info.is_dir():
                p=destino/info.filename
                if not p.is_file() or hashlib.sha256(p.read_bytes()).digest()!=hashlib.sha256(z.read(info)).digest():
                    raise ValueError(f'La entrada extraída no coincide con el ZIP: {info.filename}')
    return destino/'Material_Figuras'


def unico(raiz, patron):
    rutas=list(Path(raiz).rglob(patron))
    if len(rutas)!=1:
        raise ValueError(f'Se esperaba un archivo {patron}; encontrados: {len(rutas)}')
    return rutas[0]


def funcion_original(notebook, nombre):
    n=json.loads(Path(notebook).read_text())
    for celda in n['cells']:
        if celda['cell_type']!='code':continue
        source=''.join(celda['source'])
        for node in ast.parse(source).body:
            if isinstance(node,ast.FunctionDef) and node.name==nombre:
                namespace={'csv':csv,'re':re}
                exec(ast.get_source_segment(source,node),namespace)
                return namespace[nombre]
    raise ValueError(f'No se encontró la función original {nombre}')


def preparar_datos(raiz, salida):
    raiz,salida=Path(raiz),Path(salida)
    tablas=salida/'tablas';tablas.mkdir(parents=True,exist_ok=True)
    lectura_cv=funcion_original(unico(raiz,'CV_Grafs_paneles.ipynb'),'leer_csv_cv')
    cv={};conteos=[]
    for sensor in 'ABCD':
        for electrodo in range(1,7):
            ruta=unico(raiz,f'CV_{sensor}_E{electrodo}.csv')
            scans=lectura_cv(ruta)
            if not scans:raise ValueError(f'CV sin barridos: {ruta.name}')
            ultimo=max(scans);v,i=map(np.asarray,scans[ultimo])
            if not np.isfinite(v).all() or not np.isfinite(i).all():raise ValueError('CV no finita')
            cv[sensor,electrodo]=(v,i)
            conteos.append(dict(figura=1,solucion='',sensor=sensor,serie=f'E{electrodo}',
                n_barridos=1,corrida=ultimo,n_puntos=len(v),archivo=str(ruta.relative_to(raiz))))
    pd.DataFrame(conteos).to_csv(tablas/'conteos_CV.csv',index=False)
    eis={};registros=[];medias=[];barridos=[];desglose=[]
    for solucion,prefijo in [('NaCl','nacl'),('PBS','pbs'),('KCl','kcl')]:
        ruta=unico(raiz,f'{prefijo}_long.csv')
        d=pd.read_csv(ruta,low_memory=False)
        s=d[(d.measurement_order=='standard') & d.physical_sensor.isin(list('ABCD'))
            & d.electrode_pair.isin(['P1','P2','P3'])].copy()
        if solucion=='PBS':s=s[~s.condition.astype(str).str.strip().str.casefold().isin(['agua','water'])]
        columnas=['frequency_reference_hz','impedance_magnitude_ohm','phase_deg','z_real_ohm','z_imag_ohm']
        if s.empty or not np.isfinite(s[columnas].to_numpy()).all():raise ValueError(f'EIS inválida: {solucion}')
        if s.duplicated(['sample_id','frequency_reference_hz']).any():raise ValueError('Puntos de EIS duplicados')
        if (s.frequency_reference_hz<=0).any() or (s.impedance_magnitude_ohm<=0).any():raise ValueError('EIS no admite eje logarítmico')
        if s.dilution_percent.isna().any():raise ValueError('Concentración EIS sin etiqueta')
        # Cada espectro aporta un valor por frecuencia: media directa, sin promedios previos por sensor.
        campos=['sample_id','dilution_percent','physical_sensor','measurement_order','electrode_pair',
                'repetition','nominal_nacl_mM','nominal_kcl_mM','nominal_chloride_from_nacl_kcl_mM']
        barridos.append(s[campos].drop_duplicates('sample_id').assign(solucion=solucion))
        desglose.append(s.groupby(['dilution_percent','physical_sensor','electrode_pair'],as_index=False)
                        .agg(n_barridos=('sample_id','nunique')).assign(solucion=solucion))
        curvas=[]
        for pct,g in s.groupby('dilution_percent',sort=True):
            nominales=g[OBJETIVOS[solucion]].dropna().unique()
            if len(nominales)!=1:raise ValueError('Una dilución contiene concentraciones nominales diferentes')
            curva=g.groupby('frequency_reference_hz',as_index=False)[columnas[1:]].mean().sort_values('frequency_reference_hz')
            n=g.sample_id.nunique();nf=g.groupby('frequency_reference_hz').sample_id.nunique()
            if nf.min()!=n or nf.max()!=n:raise ValueError('El número de barridos varía por frecuencia; requiere rotulación específica')
            curvas.append((pct,n,curva))
            registros.append(dict(figura=2,solucion=solucion,sensor='A–D',orden='standard',par='P1–P3',
                                  dilucion_porcentaje=pct,objetivo_nominal_mM=float(nominales[0]),
                                  n_sensores=g.physical_sensor.nunique(),n_pares=g.electrode_pair.nunique(),
                                  n_barridos=n,n_frecuencias=len(curva),
                                  n_min_por_frecuencia=int(nf.min()),n_max_por_frecuencia=int(nf.max())))
            medias.append(curva.assign(solucion=solucion,dilucion_porcentaje=pct,n_barridos=n))
        eis[solucion]=curvas
    pd.DataFrame(registros).to_csv(tablas/'conteos_EIS.csv',index=False)
    pd.concat(barridos,ignore_index=True).to_csv(tablas/'barridos_EIS_usados.csv',index=False)
    pd.concat(desglose,ignore_index=True).to_csv(tablas/'conteos_EIS_por_sensor_par.csv',index=False)
    pd.concat(medias,ignore_index=True).to_csv(tablas/'medias_EIS_por_frecuencia.csv',index=False)

    # Funciones de entrada de la validación externa original, sin cambios de lógica.
    notebook=unico(raiz,'ML_Validacion_Externa_Mezcla_NaCl_KCl.ipynb')
    original=json.loads(notebook.read_text())
    model_root=next(raiz.rglob('Final_Models'))
    wide=pd.read_csv(unico(raiz,'mixed_nacl_kcl_ml_wide.csv'))
    dictionary=pd.read_csv(unico(raiz,'mixed_nacl_kcl_feature_dictionary.csv'))
    grupos={'Cartesian':{'z_real','z_imag'},'Polar':{'magnitude','phase'},
            'Combined':{'z_real','z_imag','phase'},'All':{'z_real','z_imag','magnitude','phase'}}
    namespace=dict(Path=Path,json=json,np=np,pd=pd,joblib=joblib,df=wide,MODEL_ROOT=model_root,
        feature_dictionary=dictionary,feature_sets={k:dictionary.loc[dictionary.feature_group.isin(v),'feature_name'].tolist() for k,v in grupos.items()},
        mean_absolute_error=mean_absolute_error,mean_squared_error=mean_squared_error,r2_score=r2_score)
    for celda in original['cells']:
        source=''.join(celda.get('source',[]))
        if celda['cell_type']=='code' and 'def preparar_entrada(' in source:
            if not all(isinstance(x,ast.FunctionDef) for x in ast.parse(source).body):raise ValueError('Celda de funciones inesperada')
            exec(source,namespace)
            break
    if 'preparar_entrada' not in namespace:raise ValueError('No se encontraron funciones de inferencia')
    predicciones=[];manifest=[]
    for meta in sorted(model_root.rglob('metadata.json')):
        m=json.loads(meta.read_text());solucion=m['solution'];ruta=meta.parent/m['model_file'];modelo=ruta.stem
        spec=dict(nombre=modelo,feature_set=m['feature_set'],target=m['target_column'])
        namespace['verificar_metadata_de_entrenamiento'](ruta,spec)
        estimator=joblib.load(ruta)
        X=namespace['preparar_entrada'](estimator,spec)
        y=np.asarray(estimator.predict(X),dtype=float).reshape(-1)
        if len(y)!=len(wide) or not np.isfinite(y).all():raise ValueError('Predicciones inválidas')
        if spec['target']!=OBJETIVOS[solucion]:raise ValueError('Objetivo incorrecto del modelo')
        t=wide[['sample_id','nominal_nacl_mM','nominal_kcl_mM','physical_sensor','electrode_pair','repetition']].copy()
        t.insert(0,'row_index',np.arange(len(t)));t['familia']=solucion;t['modelo']=modelo
        t['objetivo']=spec['target'];t['valor_real_mM']=wide[spec['target']].to_numpy()
        t['valor_predicho_mM']=y;t['error_mM']=y-t.valor_real_mM
        predicciones.append(t)
        manifest.append(dict(solucion=solucion,modelo=modelo,modo=m['model_mode'],
                             archivo=str(ruta.relative_to(raiz)),sha256=hashlib.sha256(ruta.read_bytes()).hexdigest()))
    p=pd.concat(predicciones,ignore_index=True)
    if len(manifest)!=9:raise ValueError('Se esperaban nueve modelos únicos con metadatos')
    for solucion in SOLUCIONES:
        q=p[p.familia==solucion]
        if set(q.modelo)!=set(MODELOS_MEZCLAS[solucion]):raise ValueError('Conjunto de modelos inesperado')
        if not q.groupby('modelo').size().eq(300).all():raise ValueError('Cobertura inesperada de mezclas')
        nominal=q.nominal_nacl_mM if solucion=='NaCl' else q.nominal_kcl_mM if solucion=='KCl' else q.nominal_nacl_mM+q.nominal_kcl_mM
        if not np.allclose(q.valor_real_mM,nominal,rtol=0,atol=1e-10):raise ValueError('Objetivos mal emparejados')
    mezclas=wide[['nominal_nacl_mM','nominal_kcl_mM']].drop_duplicates().sort_values(['nominal_nacl_mM','nominal_kcl_mM']).reset_index(drop=True)
    if len(mezclas)!=5:raise ValueError('Se esperaban cinco mezclas')
    mezclas['mezcla']=[f'M{i+1}' for i in range(len(mezclas))]
    p=p.merge(mezclas,on=['nominal_nacl_mM','nominal_kcl_mM'],validate='many_to_one')
    p['error_absoluto_mM']=p.error_mM.abs()
    resumen=p.groupby(['familia','modelo','mezcla'],as_index=False).agg(n=('error_mM','size'),MAE_mM=('error_absoluto_mM','mean'),sesgo_mM=('error_mM','mean'))
    if not resumen.n.eq(60).all():raise ValueError('Conteos diferentes por mezcla: adaptar leyenda común')
    p.to_csv(tablas/'predicciones_mezclas.csv',index=False)
    resumen.to_csv(tablas/'MAE_por_mezcla_modelo.csv',index=False)
    mezclas.to_csv(tablas/'clave_mezclas.csv',index=False)
    (tablas/'modelos_inferencia.json').write_text(json.dumps(manifest,indent=2,ensure_ascii=False))
    return dict(cv=cv,eis=eis,predicciones=p,resumen=resumen,mezclas=mezclas,raiz=raiz,salida=salida)


def estilo(fuentes):
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':fuentes['ejes'],
        'axes.labelsize':fuentes['ejes'],'axes.titlesize':fuentes['titulo'],
        'xtick.labelsize':fuentes['ticks'],'ytick.labelsize':fuentes['ticks'],
        'legend.fontsize':fuentes['leyenda'],'figure.facecolor':'white','axes.facecolor':'white',
        'axes.spines.top':False,'axes.spines.right':False,'axes.unicode_minus':True,
        'pdf.fonttype':42,'savefig.facecolor':'white'})


def numero(x):
    return f'{x:g}'.replace('.',',')


def limites(valores, cero=False):
    v=np.asarray(valores,dtype=float).ravel();lo,hi=float(v.min()),float(v.max())
    if cero:lo=min(lo,0);hi=max(hi,0)
    pad=max((hi-lo)*.06,.01)
    return lo-pad,hi+pad


def rotulo_panel(ax,letra,fuentes):
    ax.text(-.13,1.07,f'({letra})',transform=ax.transAxes,fontsize=fuentes['panel'],fontweight='bold')


def exportar(fig,nombre,contexto,config):
    from matplotlib.text import Text
    fig.canvas.draw();renderer=fig.canvas.get_renderer();fw,fh=fig.bbox.width,fig.bbox.height
    fuera=[]
    # Los localizadores incluyen marcas fuera de los límites; Matplotlib no las dibuja.
    ticks_no_dibujados=set()
    for ax in fig.axes:
        for axis in [ax.xaxis, ax.yaxis]:
            lo,hi=sorted(axis.get_view_interval())
            for tick in axis.get_major_ticks()+axis.get_minor_ticks():
                if not lo<=tick.get_loc()<=hi:
                    ticks_no_dibujados.update([id(tick.label1),id(tick.label2)])
    for t in fig.findobj(match=Text):
        if t.get_visible() and t.get_text() and id(t) not in ticks_no_dibujados:
            b=t.get_window_extent(renderer)
            if b.width and b.height and (b.x0 < -2 or b.y0 < -2 or b.x1 > fw+2 or b.y1 > fh+2):
                fuera.append(t.get_text()[:70])
    if fuera:raise ValueError(f'Textos fuera del lienzo en {nombre}: {fuera}')
    carpeta=contexto['salida']/'figuras';carpeta.mkdir(exist_ok=True)
    path=carpeta/f'{nombre}.png'
    # Sin bbox_inches="tight": se conserva el tamaño físico final configurado.
    fig.savefig(path,dpi=600)
    fig.savefig(carpeta/f'{nombre}.pdf')
    with Image.open(path) as im:
        registro=dict(figura=nombre,archivo=path.name,pixeles_ancho=im.width,pixeles_alto=im.height,
                      dpi_x=im.info.get('dpi',(None,None))[0],dpi_y=im.info.get('dpi',(None,None))[1],
                      ancho_cm=fig.get_figwidth()*2.54,alto_cm=fig.get_figheight()*2.54,
                      tam_titulo_pt=config['fuentes']['titulo'],tam_ejes_pt=config['fuentes']['ejes'],
                      tam_ticks_pt=config['fuentes']['ticks'],tam_leyenda_pt=config['fuentes']['leyenda'],
                      pie_incluido=False)
    contexto.setdefault('exportaciones',[]).append(registro)
    if config.get('mostrar',True):plt.show()
    plt.close(fig);gc.collect()
    return registro


def nueva_figura(config,clave):
    ancho,alto=config['dimensiones_cm'][clave]
    return plt.figure(figsize=(ancho/2.54,alto/2.54),dpi=100)


def figura_cv(c,config):
    fig=nueva_figura(config,'CV');ejes=fig.subplots(2,2)
    fig.subplots_adjust(left=.12,right=.98,bottom=.14,top=.84,hspace=.70,wspace=.46)
    fig.suptitle('Voltametrías finales',fontsize=config['fuentes']['titulo'],y=.98)
    valores_v=np.concatenate([v for v,i in c['cv'].values()]);valores_i=np.concatenate([i for v,i in c['cv'].values()])
    colores=['#0033A0','#E3000F','#D35400','#662483','#00A3E0','#009944']
    for ax,sensor,letra in zip(ejes.flat,'ABCD','abcd'):
        for electrodo in range(1,7):
            v,i=c['cv'][sensor,electrodo]
            ax.plot(v,i,color=colores[electrodo-1],lw=1.3,label=f'E{electrodo}')
        ax.set(xlim=limites(valores_v),ylim=limites(valores_i),xlabel='Potencial (V)',ylabel='Corriente (µA)')
        ax.set_title(f'Sensor {sensor}',fontsize=config['fuentes']['titulo'],pad=12)
        rotulo_panel(ax,letra,config['fuentes']);ax.grid(alpha=.18)
    handles,labels=ejes[0,0].get_legend_handles_labels()
    fig.legend(handles,labels,loc='lower center',bbox_to_anchor=(.54,.025),ncol=6,frameon=False,
               fontsize=config['fuentes']['leyenda'],handlelength=1.4,columnspacing=1)
    return exportar(fig,'01_CV_acondicionamiento',c,config)


def figura_eis(c,config):
    fig=nueva_figura(config,'EIS')
    fig.suptitle('Panorama de EIS',fontsize=config['fuentes']['titulo'],y=.98)
    ejes=[]
    for i,solucion in enumerate(SOLUCIONES):
        bottom=[23.5/34,13.3/34,3.5/34][i]
        axes=[fig.add_axes([.10+j*.30,bottom,.235,6.5/34]) for j in range(3)];ejes.append(axes)
        color_map=plt.get_cmap({'NaCl':'Blues','PBS':'Greens','KCl':'Oranges'}[solucion])
        tonos=color_map(np.linspace(.48,.98,len(c['eis'][solucion])))
        handles=[]
        for (pct,n,curva),color in zip(c['eis'][solucion],tonos):
            f=curva.frequency_reference_hz
            label=f'{numero(pct)} % (n = {n})'
            axes[0].plot(f,curva.impedance_magnitude_ohm,color=color,lw=1.7)
            axes[1].plot(f,curva.phase_deg,color=color,lw=1.7)
            axes[2].plot(curva.z_real_ohm,-curva.z_imag_ohm,color=color,lw=1.7)
            handles.append(Line2D([],[],color=color,lw=2,label=label))
        axes[0].set(xscale='log',yscale='log',xlabel='Frecuencia (Hz)',ylabel='|Z| (Ω)')
        axes[1].set(xscale='log',xlabel='Frecuencia (Hz)',ylabel='Fase (°)')
        axes[2].set(xlabel='Z′ (Ω)',ylabel='−Z″ (Ω)')
        if i==0:
            for ax,title in zip(axes,['Magnitud','Fase','Nyquist']):
                ax.set_title(title,fontsize=config['fuentes']['leyenda'],pad=22)
        axes[0].text(-.20,1.10,f'({"abc"[i]}) {solucion}',transform=axes[0].transAxes,
                     fontsize=config['fuentes']['panel'],fontweight='bold')
        for ax in axes:ax.grid(alpha=.18)
        center=[20.95/34,10.95/34,.95/34][i]
        legend_ax=fig.add_axes([.08,center-.02,.88,.04]);legend_ax.axis('off')
        legend_ax.legend(handles=handles,ncol=3,loc='center',frameon=False,
                         fontsize=config['fuentes']['leyenda'],handlelength=1.4,columnspacing=1.3)
    todo=pd.concat([curva for curves in c['eis'].values() for _,_,curva in curves],ignore_index=True)
    lo,hi=todo.frequency_reference_hz.min(),todo.frequency_reference_hz.max()
    mag_lo,mag_hi=todo.impedance_magnitude_ohm.min(),todo.impedance_magnitude_ohm.max()
    fase=limites(todo.phase_deg)
    for axes in ejes:
        for ax in axes[:2]:ax.set_xlim(lo/1.1,hi*1.1)
        axes[0].set_ylim(mag_lo/1.15,mag_hi*1.15);axes[1].set_ylim(fase)
    for indices in [[0,1],[2]]:
        datos=pd.concat([curva for i in indices for _,_,curva in c['eis'][SOLUCIONES[i]]],ignore_index=True)
        for i in indices:
            ejes[i][2].set_xlim(limites(datos.z_real_ohm,cero=True))
            ejes[i][2].set_ylim(limites(-datos.z_imag_ohm,cero=True))
    return exportar(fig,'02_panorama_EIS',c,config)


def texto_mezcla(row,n=True):
    s=f'{row.mezcla}: {numero(row.nominal_nacl_mM)}/{numero(row.nominal_kcl_mM)}'
    return s+(' (n = 60)' if n else '')


def figura_mezclas(c,config):
    fig=nueva_figura(config,'MEZCLAS');axes=fig.subplots(1,3)
    fig.subplots_adjust(left=.095,right=.98,bottom=.25,top=.80,wspace=.50)
    fig.suptitle('Predicciones en mezclas',fontsize=config['fuentes']['titulo'],y=.98)
    for ax,solucion,letra in zip(axes,SOLUCIONES,'abc'):
        modelo=SELECCIONADOS[solucion]
        s=c['predicciones'];s=s[(s.familia==solucion)&(s.modelo==modelo)]
        for mix,marker in zip(c['mezclas'].itertuples(),MARCADORES):
            g=s[s.mezcla==mix.mezcla]
            ax.scatter(g.valor_real_mM,g.valor_predicho_mM,marker=marker,color=COLORES[solucion],s=18,alpha=.35,edgecolors='none')
        lim=limites(s[['valor_real_mM','valor_predicho_mM']].to_numpy())
        ax.plot(lim,lim,'k--',lw=1.5)
        ax.set(xlim=lim,ylim=lim,xlabel='Nominal (mM)',ylabel='Predicha (mM)')
        ax.set_aspect('equal',adjustable='box')
        ax.set_title(solucion,fontsize=config['fuentes']['titulo'],pad=35)
        rotulo_panel(ax,letra,config['fuentes']);ax.grid(alpha=.18)
        subtitulo=ETIQUETAS_MODELO[modelo]+(' · Cl⁻' if solucion=='PBS' else '')
        ax.text(.5,1.02,subtitulo,transform=ax.transAxes,ha='center',fontsize=config['fuentes']['leyenda'])
    handles=[Line2D([],[],marker=marker,ls='none',color='0.3',label=texto_mezcla(row))
             for row,marker in zip(c['mezclas'].itertuples(),MARCADORES)]
    handles.append(Line2D([],[],ls='--',color='black',label='Identidad'))
    fig.legend(handles=handles,loc='lower center',bbox_to_anchor=(.53,.025),ncol=2,frameon=False,
               fontsize=config['fuentes']['leyenda'],columnspacing=1,handlelength=1.4,
               title='Mezclas: NaCl/KCl (mM)',title_fontsize=config['fuentes']['leyenda'])
    return exportar(fig,'04_predicciones_mezclas',c,config)


def figura_mae(c,config):
    fig=nueva_figura(config,'MAE')
    fig.suptitle('MAE en mezclas',fontsize=config['fuentes']['titulo'],y=.98)
    for i,(solucion,letra) in enumerate(zip(SOLUCIONES,'abc')):
        left=.065+i*.315
        ax=fig.add_axes([left,.40,.26,.39])
        s=c['resumen'];grid=s[s.familia==solucion].pivot(index='mezcla',columns='modelo',values='MAE_mM')
        grid=grid.reindex(index=c['mezclas'].mezcla,columns=MODELOS_MEZCLAS[solucion])
        if grid.isna().any().any():raise ValueError('Faltan celdas MAE')
        vmax=max(float(grid.max().max()),1e-12)
        cmap=LinearSegmentedColormap.from_list(solucion,['white',COLORES[solucion]])
        im=ax.imshow(grid.to_numpy(),aspect='auto',vmin=0,vmax=vmax,cmap=cmap)
        for row in range(5):
            for col in range(3):
                value=grid.iloc[row,col];red,green,blue,_=cmap(value/vmax)
                color='white' if .2126*red+.7152*green+.0722*blue<.48 else 'black'
                ax.text(col,row,f'{value:.2f}'.replace('.',','),ha='center',va='center',
                        fontsize=config['fuentes']['anotaciones'],color=color)
        etiquetas=[ETIQUETAS_MODELO[m].replace('Regresión lineal','Lineal').replace('SVR (RBF)','SVR\n(RBF)').replace('PCA + GPR','PCA +\nGPR') for m in grid.columns]
        ax.set_xticks(range(3),etiquetas,fontsize=config['fuentes']['leyenda'])
        ax.set_yticks(range(5),c['mezclas'].mezcla.tolist(),fontsize=config['fuentes']['leyenda'])
        ax.set_xlabel('Modelo')
        fig.text(left+.13,.89,solucion,fontsize=config['fuentes']['titulo'],ha='center',va='top')
        fig.text(left-.02,.86,f'({letra})',fontsize=config['fuentes']['panel'],fontweight='bold')
        color_ax=fig.add_axes([left,.28,.26,.018])
        cb=fig.colorbar(im,cax=color_ax,orientation='horizontal',ticks=[0,vmax/2,vmax])
        cb.set_label('MAE (mM)',fontsize=config['fuentes']['ejes'])
        cb.ax.tick_params(labelsize=config['fuentes']['ticks'])
        cb.ax.xaxis.set_major_formatter(FuncFormatter(lambda x,pos: f'{x:.1f}'.replace('.',',')))
    handles=[Line2D([],[],marker=marker,ls='none',color='0.3',label=texto_mezcla(row))
             for row,marker in zip(c['mezclas'].itertuples(),MARCADORES)]
    fig.legend(handles=handles,loc='lower center',bbox_to_anchor=(.53,.025),ncol=2,frameon=False,
               fontsize=config['fuentes']['leyenda'],columnspacing=1,handlelength=1,
               title='Mezclas: NaCl/KCl (mM)',title_fontsize=config['fuentes']['leyenda'])
    return exportar(fig,'05_mapas_MAE',c,config)


def seleccionar_fuentes_loco(archivo_zip, destino):
    """Copia solo fuentes LOCO pertinentes, sin modificar su contenido."""
    destino=Path(destino);destino.mkdir(parents=True,exist_ok=True)
    archivo_zip=Path(archivo_zip)
    alias={'Linear Regression':'OLS','Ridge Regression':'Ridge','PLS Regression':'PLS',
           'SVR RBF':'SVR','PCA + GPR':'GPR-PCA'}
    modos={'baseline':'Base','search':'Optimizado'}
    registros=[]
    with zipfile.ZipFile(archivo_zip) as z:
        for info in z.infolist():
            p=PurePosixPath(info.filename)
            if p.is_absolute() or '..' in p.parts:raise ValueError('Ruta ZIP no segura')
        for nombre in sorted(z.namelist()):
            if not nombre.endswith('/metadata.json'):continue
            m=json.loads(z.read(nombre));sol=m.get('solution');modo=modos.get(m.get('model_mode'))
            if m.get('separation')!='leave_one_concentration_out' or m.get('feature_set')!='Combined':continue
            if sol not in FINALISTAS_LOCO or modo is None:continue
            modelos=[alias[x] for x in m.get('models',[]) if x in alias]
            if not any((modelo,modo) in FINALISTAS_LOCO[sol] for modelo in modelos):continue
            base=PurePosixPath(nombre).parent
            if str(base/'predictions.csv') not in z.namelist():raise ValueError(f'Faltan predicciones: {base}')
            for basename in ['metadata.json','predictions.csv','metrics.csv','parameters.csv']:
                member=str(base/basename)
                if member not in z.namelist():continue
                contenido=z.read(member);ruta=destino/Path(member);ruta.parent.mkdir(parents=True,exist_ok=True)
                if ruta.exists() and ruta.read_bytes()!=contenido:raise ValueError(f'Fuente existente diferente: {ruta}')
                ruta.write_bytes(contenido)
                registros.append(dict(archivo=member,sha256=hashlib.sha256(contenido).hexdigest()))
    if not registros:raise ValueError('No se encontraron fuentes LOCO de los finalistas solicitados')
    origen=dict(archivo_zip=archivo_zip.name,sha256_zip=hashlib.sha256(archivo_zip.read_bytes()).hexdigest(),
                criterio='Tres modelos por solución indicados por el usuario; Combined; todas las exclusiones disponibles',
                archivos=registros)
    (destino/'origen_LOCO.json').write_text(json.dumps(origen,indent=2,ensure_ascii=False))
    return origen


def consolidar_loco(carpeta_fuentes, raiz_datasets, archivo_salida):
    """Normaliza predicciones exportadas y verifica sus identidades y objetivos."""
    carpeta_fuentes,raiz_datasets,archivo_salida=map(Path,[carpeta_fuentes,raiz_datasets,archivo_salida])
    alias={'Linear Regression':'OLS','Ridge Regression':'Ridge','PLS Regression':'PLS',
           'SVR RBF':'SVR','PCA + GPR':'GPR-PCA'}
    modos={'baseline':'Base','search':'Optimizado'}
    desarrollo={s:pd.read_csv(unico(raiz_datasets,f'{prefijo}_ml_wide.csv'))
                for s,prefijo in [('NaCl','nacl'),('PBS','pbs'),('KCl','kcl')]}
    filas=[];proveniencia=[]
    for meta in sorted(carpeta_fuentes.rglob('metadata.json')):
        m=json.loads(meta.read_text());sol=m.get('solution');modo=modos.get(m.get('model_mode'))
        if m.get('separation')!='leave_one_concentration_out' or m.get('feature_set')!='Combined':continue
        if sol not in FINALISTAS_LOCO or modo is None:continue
        if m.get('target_column')!=OBJETIVOS[sol]:raise ValueError(f'Objetivo LOCO incorrecto: {meta}')
        p=pd.read_csv(meta.parent/'predictions.csv')
        columnas={'row_index','modelo','valor_real','valor_predicho','solution','feature_set',
                  'separation','model_mode','test_concentration','target_column','concentracion_porcentaje'}
        if columnas-set(p):raise ValueError(f'Faltan columnas LOCO: {meta.parent.name}')
        for col,valor in [('solution',sol),('feature_set','Combined'),('separation','leave_one_concentration_out'),
                          ('model_mode',m['model_mode']),('target_column',OBJETIVOS[sol])]:
            if not p[col].eq(valor).all():raise ValueError(f'Metadatos inconsistentes: {col}')
        excl=float(m['test_concentration'])
        for col in ['test_concentration','concentracion_porcentaje']:
            if not np.isclose(pd.to_numeric(p[col]),excl,rtol=0,atol=1e-10).all():raise ValueError('Exclusión inconsistente')
        for raw_model,g in p.groupby('modelo',sort=False):
            model=alias.get(raw_model)
            if (model,modo) not in FINALISTAS_LOCO[sol]:continue
            required=['row_index','valor_real','valor_predicho']
            if not np.isfinite(g[required].apply(pd.to_numeric).to_numpy()).all():raise ValueError('LOCO no finito')
            indices=g.row_index.to_numpy()
            if not np.equal(indices,indices.astype(int)).all() or g.row_index.duplicated().any():raise ValueError('Identidades LOCO inválidas')
            indices=indices.astype(int);d=desarrollo[sol]
            if (indices<0).any() or (indices>=len(d)).any():raise ValueError('Índice LOCO fuera del dataset')
            observaciones=d.iloc[indices]
            if not np.allclose(observaciones[OBJETIVOS[sol]],g.valor_real,rtol=0,atol=1e-8):raise ValueError('Objetivos LOCO mal emparejados con el dataset')
            if not observaciones.dilution_percent.eq(excl).all():raise ValueError('Fila fuera de la concentración excluida')
            esperadas=set(np.flatnonzero(d.dilution_percent.eq(excl)))
            if set(indices)!=esperadas:raise ValueError('La exportación no cubre todas las observaciones de la exclusión')
            if 'error' in g and not np.allclose(g.error,g.valor_predicho-g.valor_real,rtol=0,atol=1e-8):raise ValueError('Error guardado inconsistente')
            q=pd.DataFrame({'solution':sol,'model':model,'configuration':modo,'feature_set':'Combined',
                'excluded_pct':excl,'true_value':g.valor_real.to_numpy(),'predicted_value':g.valor_predicho.to_numpy(),
                'observation_id':observaciones.sample_id.to_numpy(),'row_index':indices,
                'target_name':OBJETIVOS[sol],'target_units':'mM','source_experiment':m['experiment_id'],
                'source_predictions':str((meta.parent/'predictions.csv').relative_to(carpeta_fuentes))})
            filas.append(q)
            proveniencia.append(dict(solucion=sol,modelo=model,modo=modo,exclusion_porcentaje=excl,n=len(q),
                nominal_mM=float(q.true_value.iloc[0]),experimento=m['experiment_id'],
                archivo_predicciones=str((meta.parent/'predictions.csv').relative_to(carpeta_fuentes)),
                sha256_predicciones=hashlib.sha256((meta.parent/'predictions.csv').read_bytes()).hexdigest()))
    if not filas:raise ValueError('No hay predicciones LOCO utilizables')
    normalizada=pd.concat(filas,ignore_index=True)
    if normalizada.duplicated(['solution','model','configuration','feature_set','excluded_pct','observation_id']).any():
        raise ValueError('Fuentes LOCO duplicadas o incompatibles; no se elige una silenciosamente')
    normalizada.to_csv(archivo_salida,index=False)
    pd.DataFrame(proveniencia).to_csv(archivo_salida.with_name('procedencia_LOCO.csv'),index=False)
    return normalizada


def figura_loco(c,config):
    archivo=Path(config['archivo_LOCO'])
    if not archivo.is_file():
        mensaje=('Pendiente: no se recibieron predicciones individuales LOCO. Se necesita '
            'reporte_predicciones_finalistas.csv, exportado por EIS_Resultados_ML_Tesis_final.ipynb, '
            'con todas las exclusiones evaluadas; alternativamente, los experimentos originales con '
            'predictions.csv y metadata.json. No se usan predicciones de modelos finales ajustados '
            'con todos los datos para simular exclusiones.')
        (c['salida']/'PENDIENTE_LOCO.txt').write_text(mensaje)
        print(mensaje)
        return dict(figura=3,estado='pendiente',detalle=mensaje)
    p=pd.read_csv(archivo)
    required={'solution','model','configuration','feature_set','excluded_pct','true_value','predicted_value','observation_id'}
    if required-set(p):raise ValueError(f'CSV LOCO: faltan columnas {sorted(required-set(p))}')
    if p[list(required)].isna().any().any():raise ValueError('CSV LOCO con valores obligatorios faltantes')
    for col in ['excluded_pct','true_value','predicted_value']:p[col]=pd.to_numeric(p[col],errors='raise')
    if not np.isfinite(p[['excluded_pct','true_value','predicted_value']].to_numpy()).all():raise ValueError('LOCO no finito')
    elegidas=[];conteos=[];niveles={}
    for solucion in SOLUCIONES:
        partes=[]
        for model,mode in FINALISTAS_LOCO[solucion]:
            g=p[(p.solution==solucion)&(p.model==model)&(p.configuration==mode)&(p.feature_set=='Combined')].copy()
            if g.empty:raise ValueError(f'Falta LOCO: {solucion}/{model}/{mode}')
            if g.duplicated(['excluded_pct','observation_id']).any():raise ValueError('LOCO duplicado')
            partes.append(g)
        plan=sorted(set().union(*(set(g.excluded_pct) for g in partes)))
        niveles[solucion]=plan
        for exclusion in plan:
            referencia=None;ids_referencia=None
            for g in partes:
                h=g[g.excluded_pct==exclusion]
                if h.empty:raise ValueError(f'Exclusión LOCO incompleta: {solucion}/{exclusion}')
                if h.true_value.nunique()!=1:raise ValueError('Una exclusión mezcla objetivos nominales diferentes')
                nominal=float(h.true_value.iloc[0])
                prefijo={'NaCl':'nacl','PBS':'pbs','KCl':'kcl'}[solucion]
                desarrollo=pd.read_csv(unico(c['raiz'],f'{prefijo}_ml_wide.csv'))
                esperados=desarrollo.loc[desarrollo.dilution_percent==exclusion,OBJETIVOS[solucion]].dropna().unique()
                if len(esperados)!=1 or not np.isclose(nominal,esperados[0],rtol=0,atol=1e-8):
                    raise ValueError('El objetivo LOCO no coincide con la concentración nominal del dataset de esa solución')
                if referencia is None:referencia=nominal;ids_referencia=set(h.observation_id)
                if nominal!=referencia or set(h.observation_id)!=ids_referencia:raise ValueError('LOCO no compara las mismas observaciones')
                conteos.append(dict(solucion=solucion,modelo=h.model.iloc[0],modo=h.configuration.iloc[0],
                                    exclusion_porcentaje=exclusion,nominal_mM=nominal,n=len(h)))
        elegidas.extend(partes)
    q=pd.concat(elegidas,ignore_index=True)
    counts=pd.DataFrame(conteos);counts.to_csv(c['salida']/'tablas'/'conteos_LOCO.csv',index=False)
    q.to_csv(c['salida']/'tablas'/'predicciones_LOCO_usadas.csv',index=False)
    fig=nueva_figura(config,'LOCO');axes=fig.subplots(1,3)
    fig.subplots_adjust(left=.075,right=.985,bottom=.22,top=.83,wspace=.50)
    fig.suptitle('Predicciones LOCO',fontsize=config['fuentes']['titulo'],y=.98)
    labels={'OLS':'Regresión lineal','PLS':'PLS','Ridge':'Ridge','SVR':'SVR (RBF)','GPR-PCA':'PCA + GPR'}
    for ax,solucion,letra in zip(axes,SOLUCIONES,'abc'):
        rgb=np.array(plt.matplotlib.colors.to_rgb(COLORES[solucion]));handles=[]
        for j,(model,mode) in enumerate(FINALISTAS_LOCO[solucion]):
            values=[]
            for level in niveles[solucion]:
                values.append(q[(q.solution==solucion)&(q.model==model)&(q.excluded_pct==level)].predicted_value.to_numpy())
            color=tuple((1-j*.25)*rgb+j*.25*np.ones(3))
            boxes=ax.boxplot(values,positions=np.arange(len(values))+(j-1)*.24,widths=.21,
                patch_artist=True,manage_ticks=False,whis=1.5,showfliers=True,
                medianprops={'color':'black'},flierprops={'marker':'.','markersize':2,'alpha':.4})
            for box in boxes['boxes']:box.set_facecolor(color)
            handles.append(plt.matplotlib.patches.Patch(facecolor=color,edgecolor='black',label=f'{labels[model]} · {mode.lower()}'))
        nominales=[]
        for i,level in enumerate(niveles[solucion]):
            g=counts[(counts.solucion==solucion)&(counts.exclusion_porcentaje==level)]
            nominal=float(g.nominal_mM.iloc[0]);nominales.append(numero(nominal))
            ax.plot([i-.38,i+.38],[nominal,nominal],'k--',lw=1.4)
        ax.set_xticks(range(len(nominales)),nominales)
        ax.set(xlabel='Nominal excluida (mM)',ylabel='Predicha (mM)')
        ax.set_title(solucion,fontsize=config['fuentes']['titulo']);rotulo_panel(ax,letra,config['fuentes'])
        ax.grid(axis='y',alpha=.18)
        ax.legend(handles=handles,loc='upper center',bbox_to_anchor=(.5,-.12),frameon=False,
                  fontsize=config['fuentes']['leyenda'],handlelength=1)
    exportar(fig,'03_cajas_LOCO',c,config)
    pendiente=c['salida']/'PENDIENTE_LOCO.txt'
    if pendiente.exists():pendiente.unlink()
    return dict(figura=3,estado='generada',detalle='Predicciones LOCO recibidas y verificadas')


def finalizar(c,config,estado_loco):
    registros=pd.DataFrame(c.get('exportaciones',[]))
    registros.to_csv(c['salida']/'tablas'/'dimensiones_exportaciones.csv',index=False)
    estados=[dict(figura=i,estado='generada') for i in [1,2,4,5]]+[estado_loco]
    pd.DataFrame(estados).sort_values('figura').to_csv(c['salida']/'tablas'/'estado_figuras.csv',index=False)
    fuentes=[]
    for path in sorted(c['raiz'].rglob('*')):
        if path.is_file():fuentes.append(dict(archivo=str(path.relative_to(c['raiz'])),sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
    manifiesto=dict(configuracion={**config,'archivo_LOCO':str(config['archivo_LOCO'])},
        entradas=fuentes,predicciones_totales=len(c['predicciones']),modelos_unicos=9,
        estado_LOCO=estado_loco,versiones={})
    origen_loco=Path(config['archivo_LOCO']).parent/'datos_LOCO'/'origen_LOCO.json'
    if origen_loco.is_file():manifiesto['origen_LOCO']=json.loads(origen_loco.read_text())
    import importlib.metadata
    for pkg in ['numpy','pandas','matplotlib','scikit-learn','joblib','Pillow']:
        manifiesto['versiones'][pkg]=importlib.metadata.version(pkg)
    (c['salida']/'tablas'/'manifiesto.json').write_text(json.dumps(manifiesto,indent=2,ensure_ascii=False))
    return pd.DataFrame(estados).sort_values('figura')
