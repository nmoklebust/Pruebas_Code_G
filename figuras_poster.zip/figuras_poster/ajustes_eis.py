"""Ajustes documentales de EIS: fase de acondicionamiento y repetibilidad."""
from pathlib import Path
import ast,csv,json,math,re,unicodedata,copy
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.ticker import NullFormatter, MaxNLocator, ScalarFormatter
import figuras_poster as f

TITULO_FASE='Comparación de diagramas de fase de Bode entre sensores'
# Una asignación fija por identidad, reutilizada en magnitud, fase y Nyquist.
COLORES_CUALITATIVOS=['#0072B2','#D55E00','#009E73','#CC79A7','#332288']
TRAZOS=['-','--','-.',':',(0,(5,1,1,1,1,1))]


def cargar_fase_acondicionamiento(raiz,salida):
    """Reutiliza las tres funciones originales de lectura, incluida la convención de fase."""
    raiz,salida=Path(raiz),Path(salida)
    original=json.loads(f.unico(raiz,'CV_Grafs_paneles.ipynb').read_text())
    namespace=dict(csv=csv,re=re,math=math,unicodedata=unicodedata)
    wanted=['normalizar_encabezado','identificar_columnas','leer_csv_eis']
    for cell in original['cells']:
        if cell['cell_type']!='code':continue
        source=''.join(cell['source'])
        for node in ast.parse(source).body:
            if isinstance(node,ast.FunctionDef) and node.name in wanted:
                exec(ast.get_source_segment(source,node),namespace)
    if not all(k in namespace for k in wanted):raise ValueError('Faltan lectores EIS originales')
    datos={};filas=[]
    for sensor in 'ABCD':
        for electrodo in range(1,7):
            path=f.unico(raiz,f'EIS_{sensor}_E{electrodo}.csv')
            values=namespace['leer_csv_eis'](path)
            if len(values['frecuencia'])!=41:raise ValueError('Cobertura EIS de acondicionamiento inesperada')
            datos[sensor,electrodo]=values
            for i in range(len(values['frecuencia'])):
                filas.append(dict(sensor=sensor,electrodo=electrodo,archivo=str(path.relative_to(raiz)),
                                  **{k:float(v[i]) for k,v in values.items()}))
    pd.DataFrame(filas).to_csv(salida/'tablas'/'EIS_acondicionamiento_usado.csv',index=False)
    return datos


def figura_fase_acondicionamiento(c,config):
    datos=cargar_fase_acondicionamiento(c['raiz'],c['salida'])
    # Conserva tamaño, escalas y tipografía del panel original; solo se corrige su título.
    cfg=copy.deepcopy(config)
    cfg['dimensiones_cm']['FASE_CV']=(40.64,27.94)  # 16 × 11 pulgadas, como el notebook fuente.
    cfg['fuentes']=dict(titulo=23,ejes=15,ticks=14,leyenda=11,anotaciones=17,panel=17)
    fig=f.nueva_figura(cfg,'FASE_CV');axes=fig.subplots(2,2)
    fig.subplots_adjust(left=.09,right=.98,bottom=.08,top=.88,wspace=.24,hspace=.40)
    colores=['#0033A0','#E3000F','#D35400','#662483','#00A3E0','#009944']
    frecuencia=np.concatenate([d['frecuencia'] for d in datos.values()])
    fase=np.concatenate([d['fase'] for d in datos.values()])
    factor=10**((np.log10(frecuencia.max())-np.log10(frecuencia.min()))*.04)
    span=(fase.max()-fase.min())*.04
    for ax,sensor,letter in zip(axes.flat,'ABCD','abcd'):
        for e in range(1,7):
            d=datos[sensor,e]
            ax.plot(d['frecuencia'],d['fase'],color=colores[e-1],lw=2,label=f'E{e}')
        ax.set(xscale='log',xlim=(frecuencia.min()/factor,frecuencia.max()*factor),
               ylim=(fase.min()-span,fase.max()+span))
        ax.set_xlabel('Frecuencia (Hz)',fontsize=15);ax.set_ylabel('Fase (°)',fontsize=15)
        ax.set_title(f'({letter}) Sensor {sensor}',fontsize=17,loc='left')
        ax.tick_params(labelsize=14);ax.grid(alpha=.25)
        ax.legend(title='Electrodo',ncol=2,fontsize=11,title_fontsize=11)
    fig.suptitle(TITULO_FASE,fontsize=23)
    return f.exportar(fig,'06_Bode_fase_CV_cuatro_sensores',c,cfg)


def preparar_repetibilidad(raiz,salida,seleccion):
    sol=seleccion['solution'];prefix={'NaCl':'nacl','PBS':'pbs','KCl':'kcl'}[sol]
    d=pd.read_csv(f.unico(raiz,f'{prefix}_long.csv'),low_memory=False)
    base=d[(d.dilution_percent==seleccion['dilution_percent'])&
           (d.measurement_order==seleccion['measurement_order'])&
           d.physical_sensor.isin(list('ABCD'))&d.electrode_pair.isin(['P1','P2','P3'])].copy()
    sensor=base[base.physical_sensor==seleccion['physical_sensor']]
    par=sensor[sensor.electrode_pair==seleccion['electrode_pair']]
    if base.empty or sensor.empty or par.empty:raise ValueError('Selección de repetibilidad sin datos')
    cols=['impedance_magnitude_ohm','phase_deg','z_real_ohm','z_imag_ohm']
    if base.duplicated(['sample_id','frequency_reference_hz']).any():raise ValueError('Puntos EIS duplicados')
    if not np.isfinite(base[['frequency_reference_hz',*cols]].to_numpy()).all():raise ValueError('EIS no finita')
    if (base.frequency_reference_hz<=0).any() or (base.impedance_magnitude_ohm<=0).any():raise ValueError('Valores no positivos en Bode')
    rows=[[],[],[]];counts=[];points=[]
    def agregar(row,identity,label,g,individual=False):
        n=g.sample_id.nunique();freq_counts=g.groupby('frequency_reference_hz').sample_id.nunique()
        if freq_counts.nunique()!=1 or freq_counts.iloc[0]!=n:raise ValueError('Cobertura variable por frecuencia')
        if individual:
            if n!=1:raise ValueError('Un barrido contiene varias identidades')
            curve=g.sort_values('frequency_reference_hz')[['frequency_reference_hz',*cols]].copy()
        else:
            # Media directa por frecuencia de todos los espectros del par o sensor.
            curve=g.groupby('frequency_reference_hz',as_index=False)[cols].mean().sort_values('frequency_reference_hz')
        index=len(rows[row]);color=COLORES_CUALITATIVOS[index];style=TRAZOS[index]
        rows[row].append(dict(identidad=identity,etiqueta=label,curva=curve,color=color,trazo=style,n=n))
        counts.append(dict(fila='abc'[row],identidad=identity,etiqueta=label,n_barridos=n,
                           color=color,trazo=str(style),n_frecuencias=len(curve)))
        points.append(curve.assign(fila='abc'[row],identidad=identity,n_barridos=n))
    barridos=par[['sample_id','repetition']].drop_duplicates().sort_values(['repetition','sample_id'])
    if barridos.repetition.duplicated().any():raise ValueError('Números de barrido repetidos; no se renombran silenciosamente')
    for t in barridos.itertuples():
        label=f'Barrido {f.numero(t.repetition)}'
        agregar(0,str(t.sample_id),label,par[par.sample_id==t.sample_id],True)
    for nombre,g in sensor.groupby('electrode_pair',sort=True):
        agregar(1,f'Par {nombre}',f'Par {nombre} (n = {g.sample_id.nunique()})',g)
    for nombre,g in base.groupby('physical_sensor',sort=True):
        agregar(2,f'Sensor {nombre}',f'Sensor {nombre} (n = {g.sample_id.nunique()})',g)
    pd.DataFrame(counts).to_csv(Path(salida)/'tablas'/'conteos_repetibilidad_EIS.csv',index=False)
    pd.concat(points,ignore_index=True).to_csv(Path(salida)/'tablas'/'curvas_repetibilidad_EIS.csv',index=False)
    base[['sample_id','repetition','physical_sensor','electrode_pair','measurement_order','dilution_percent']].drop_duplicates().to_csv(
        Path(salida)/'tablas'/'barridos_repetibilidad_EIS.csv',index=False)
    return rows


def figura_repetibilidad(c,config,curvas,seleccion,modo='logaritmica'):
    if modo not in ['logaritmica','lineal']:raise ValueError('Modo Bode inválido')
    fig=f.nueva_figura(config,'REPETIBILIDAD');escala=config.get('escala_tipografica',1.0)
    fuente_leyenda=f.tam_leyenda_word(config,fig.get_figwidth()*2.54)
    fig.suptitle('Repetibilidad EIS',fontsize=config['fuentes']['titulo'],y=.98)
    all_points=pd.concat([t['curva'] for row in curvas for t in row],ignore_index=True)
    limits={k:f.limites(all_points[k]) for k in ['phase_deg','z_real_ohm']}
    lim_imag=f.limites(-all_points.z_imag_ohm)
    freq=(all_points.frequency_reference_hz.min()/1.1,all_points.frequency_reference_hz.max()*1.1)
    mag=(all_points.impedance_magnitude_ohm.min()/1.1,all_points.impedance_magnitude_ohm.max()*1.1)
    for i,row in enumerate(curvas):
        bottom=[24.0/34,13.8/34,4.0/34][i]
        ancho_panel=.22 if config.get('perfil_word') else .235
        axes=[fig.add_axes([.10+j*.30,bottom,ancho_panel,6.0/34]) for j in range(3)]
        for item in row:
            d=item['curva'];kwargs=dict(color=item['color'],linestyle=item['trazo'],linewidth=1.8*escala)
            axes[0].plot(d.frequency_reference_hz,d.impedance_magnitude_ohm,**kwargs)
            axes[1].plot(d.frequency_reference_hz,d.phase_deg,**kwargs)
            axes[2].plot(d.z_real_ohm,-d.z_imag_ohm,**kwargs)
        axes[0].set(xscale='log' if modo=='logaritmica' else 'linear',yscale='log' if modo=='logaritmica' else 'linear',
                    xlim=freq,ylim=mag,xlabel='Frecuencia (Hz)',ylabel='|Z| (Ω)')
        axes[1].set(xscale='log' if modo=='logaritmica' else 'linear',xlim=freq,ylim=limits['phase_deg'],
                    xlabel='Frecuencia (Hz)',ylabel='Fase (°)')
        axes[2].set(xlim=limits['z_real_ohm'],ylim=lim_imag,xlabel='Z′ (Ω)',ylabel='−Z″ (Ω)')
        # Valores de magnitud legibles aun con un intervalo estrecho sobre el eje logarítmico.
        axes[0].yaxis.set_major_locator(MaxNLocator(nbins=4))
        fmt=ScalarFormatter(useOffset=False);fmt.set_scientific(False)
        axes[0].yaxis.set_major_formatter(fmt)
        axes[0].yaxis.set_minor_formatter(NullFormatter())
        for ax in axes[:2]:ax.xaxis.set_minor_formatter(NullFormatter())
        if i==0:
            for ax,title in zip(axes,['Magnitud','Fase','Nyquist']):
                ax.set_title(title,fontsize=config['fuentes']['leyenda'],pad=22*escala)
        titulo=['Barridos','Pares','Sensores'][i]
        fig.text(.02,bottom+(6.0/34)*1.10,f'({"abc"[i]}) {titulo}',
                 fontsize=config['fuentes']['panel'],fontweight='bold')
        for ax in axes:
            ax.tick_params(labelsize=config['fuentes']['ticks']);ax.grid(alpha=.18)
            if config.get('perfil_word'):
                ax.xaxis.labelpad=2;ax.yaxis.labelpad=2
                ax.tick_params(axis='both',which='major',pad=2)
            ax.ticklabel_format(axis='both',style='plain',useOffset=False) if ax.get_xscale()=='linear' and ax.get_yscale()=='linear' else None
        handles=[Line2D([],[],color=t['color'],linestyle=t['trazo'],lw=1.8*escala,label=t['etiqueta']) for t in row]
        center=[21.1/34,10.95/34,1.2/34][i]
        band=fig.add_axes([.08,center-.02,.88,.04]);band.axis('off')
        band.legend(handles=handles,ncol=3,loc='center',frameon=False,fontsize=fuente_leyenda,
                    handlelength=3.0,columnspacing=1.2)
    name='07_repetibilidad_EIS_logaritmica' if modo=='logaritmica' else '08_repetibilidad_EIS_lineal'
    return f.exportar(fig,name,c,config)


def exportar_word(c,config,curvas,seleccion):
    """Exportación directa al ancho de inserción, sin redimensionar imágenes rasterizadas."""
    width=float(config['ancho_insercion_word_cm']);scale=width/34.0
    cfg=copy.deepcopy(config)
    cfg['dimensiones_cm']['EIS']=(width,width*1.25);cfg['dimensiones_cm']['REPETIBILIDAD']=(width,width*1.25)
    cfg['perfil_word']=True
    cfg['fuentes']=dict(titulo=18,ejes=9,ticks=8,leyenda=9,anotaciones=9,panel=9)
    cfg['escala_tipografica']=scale
    cw={**c,'salida':c['salida']/'Word','exportaciones':[]}
    cw['salida'].mkdir(exist_ok=True)
    f.estilo(cfg['fuentes'])
    f.figura_eis(cw,cfg)
    for mode in ['logaritmica','lineal']:figura_repetibilidad(cw,cfg,curvas,seleccion,mode)
    table=pd.DataFrame(cw['exportaciones']);table.to_csv(cw['salida']/'dimensiones_exportaciones.csv',index=False)
    f.estilo(config['fuentes'])
    return table
